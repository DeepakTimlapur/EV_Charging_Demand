from pathlib import Path

import pandas as pd


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_PATH = (
    PROJECT_ROOT
    / "data"
    / "EV_Charging_Demand_Dataset_Full.csv"
)


# ============================================================
# LOAD AND PREPARE RAW DATA
# ============================================================

def load_prepared_data() -> pd.DataFrame:
    """
    Load the raw EV charging dataset and convert timestamp
    columns to datetime.

    Returns
    -------
    pd.DataFrame
        Prepared raw dataset.
    """

    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found at:\n{DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)

    datetime_columns = [
        "timestamp",
        "arrival_time",
        "charging_start_time",
        "charging_end_time",
    ]

    for column in datetime_columns:
        df[column] = pd.to_datetime(
            df[column],
            errors="coerce",
        )

    # Sort chronologically.
    df = df.sort_values(
        ["timestamp", "station_id"]
    ).reset_index(drop=True)

    return df


# ============================================================
# CREATE HOURLY STATION PANEL
# ============================================================

def create_hourly_station_panel(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Create a complete station-hour panel.

    The original dataset contains individual charging events.
    We aggregate those events to station-hour level.

    If no charging event is recorded for a station during
    an hour, activity-related quantities are represented as
    zero.

    This is an explicit modeling assumption.
    """

    df = df.copy()

    # --------------------------------------------------------
    # Convert each observation into an hourly bucket.
    # --------------------------------------------------------

    df["hour"] = df["timestamp"].dt.floor("h")

    # --------------------------------------------------------
    # Aggregate event-level data to station-hour level.
    # --------------------------------------------------------

    hourly = (
        df.groupby(
            ["station_id", "hour"],
            as_index=False,
        )
        .agg(
            charging_demand=(
                "charging_demand",
                "mean",
            ),
            station_load=(
                "station_load",
                "mean",
            ),
            queue_length=(
                "queue_length",
                "mean",
            ),
            energy_consumed_kWh=(
                "energy_consumed_kWh",
                "sum",
            ),
            waiting_time=(
                "waiting_time",
                "mean",
            ),
            electricity_price=(
                "electricity_price",
                "mean",
            ),
            renewable_energy_ratio=(
                "renewable_energy_ratio",
                "mean",
            ),
        )
    )

    # --------------------------------------------------------
    # Create the complete global hourly range.
    # --------------------------------------------------------

    min_hour = df["hour"].min()
    max_hour = df["hour"].max()

    all_hours = pd.date_range(
        start=min_hour,
        end=max_hour,
        freq="h",
    )

    # --------------------------------------------------------
    # Get all stations.
    # --------------------------------------------------------

    stations = sorted(
        df["station_id"].unique()
    )

    # --------------------------------------------------------
    # Create complete station × hour grid.
    # --------------------------------------------------------

    grid = pd.MultiIndex.from_product(
        [stations, all_hours],
        names=[
            "station_id",
            "hour",
        ],
    ).to_frame(index=False)

    # --------------------------------------------------------
    # Merge observed station-hour data onto complete grid.
    # --------------------------------------------------------

    panel = grid.merge(
        hourly,
        on=[
            "station_id",
            "hour",
        ],
        how="left",
    )

    # --------------------------------------------------------
    # Handle empty station-hours.
    #
    # No event recorded during a station-hour means:
    #
    # charging demand        = 0
    # station load           = 0
    # queue length           = 0
    # energy consumed        = 0
    # waiting time           = 0
    #
    # This is an explicit modeling assumption.
    # --------------------------------------------------------

    zero_fill_columns = [
        "charging_demand",
        "station_load",
        "queue_length",
        "energy_consumed_kWh",
        "waiting_time",
    ]

    for column in zero_fill_columns:
        panel[column] = panel[column].fillna(0)

    return panel


# ============================================================
# CALENDAR FEATURES
# ============================================================

def add_calendar_features(
    panel: pd.DataFrame,
) -> pd.DataFrame:
    """
    Add calendar features derived only from the timestamp.

    These features do not use future observations.
    """

    panel = panel.copy()

    panel["hour_of_day"] = (
        panel["hour"].dt.hour
    )

    panel["day_of_week"] = (
        panel["hour"].dt.dayofweek
    )

    panel["day_of_month"] = (
        panel["hour"].dt.day
    )

    panel["month"] = (
        panel["hour"].dt.month
    )

    panel["is_weekend"] = (
        panel["day_of_week"] >= 5
    ).astype(int)

    return panel


# ============================================================
# LAG FEATURES
# ============================================================

def add_lag_features(
    panel: pd.DataFrame,
) -> pd.DataFrame:
    """
    Create historical lag features.

    All lagged features use information from previous hours.

    No contemporaneous demand is used as a direct predictor.
    """

    panel = panel.copy()

    panel = panel.sort_values(
        [
            "station_id",
            "hour",
        ]
    ).reset_index(drop=True)

    grouped = panel.groupby(
        "station_id",
        sort=False,
    )

    # --------------------------------------------------------
    # Historical charging demand
    # --------------------------------------------------------

    panel["demand_lag_1h"] = (
        grouped["charging_demand"]
        .shift(1)
    )

    panel["demand_lag_2h"] = (
        grouped["charging_demand"]
        .shift(2)
    )

    panel["demand_lag_3h"] = (
        grouped["charging_demand"]
        .shift(3)
    )

    panel["demand_lag_24h"] = (
        grouped["charging_demand"]
        .shift(24)
    )

    # --------------------------------------------------------
    # Historical station load
    # --------------------------------------------------------

    panel["station_load_lag_1h"] = (
        grouped["station_load"]
        .shift(1)
    )

    panel["station_load_lag_24h"] = (
        grouped["station_load"]
        .shift(24)
    )

    # --------------------------------------------------------
    # Historical queue length
    # --------------------------------------------------------

    panel["queue_lag_1h"] = (
        grouped["queue_length"]
        .shift(1)
    )

    panel["queue_lag_24h"] = (
        grouped["queue_length"]
        .shift(24)
    )

    return panel


# ============================================================
# ROLLING FEATURES
# ============================================================

def add_rolling_features(
    panel: pd.DataFrame,
) -> pd.DataFrame:
    """
    Create historical rolling demand features.

    IMPORTANT:
    Rolling features are calculated from demand shifted by
    one hour.

    Therefore, the current hour's demand is never included
    in its own rolling feature.
    """

    panel = panel.copy()

    panel = panel.sort_values(
        [
            "station_id",
            "hour",
        ]
    ).reset_index(drop=True)

    # --------------------------------------------------------
    # First shift demand by one hour.
    # --------------------------------------------------------

    panel["demand_previous_hour"] = (
        panel.groupby(
            "station_id",
            sort=False,
        )["charging_demand"]
        .shift(1)
    )

    # --------------------------------------------------------
    # 3-hour historical rolling mean.
    # --------------------------------------------------------

    panel["demand_rolling_mean_3h"] = (
        panel.groupby(
            "station_id",
            sort=False,
        )["demand_previous_hour"]
        .transform(
            lambda s: s.rolling(
                window=3,
                min_periods=3,
            ).mean()
        )
    )

    # --------------------------------------------------------
    # 6-hour historical rolling mean.
    # --------------------------------------------------------

    panel["demand_rolling_mean_6h"] = (
        panel.groupby(
            "station_id",
            sort=False,
        )["demand_previous_hour"]
        .transform(
            lambda s: s.rolling(
                window=6,
                min_periods=6,
            ).mean()
        )
    )

    # --------------------------------------------------------
    # 24-hour historical rolling mean.
    # --------------------------------------------------------

    panel["demand_rolling_mean_24h"] = (
        panel.groupby(
            "station_id",
            sort=False,
        )["demand_previous_hour"]
        .transform(
            lambda s: s.rolling(
                window=24,
                min_periods=24,
            ).mean()
        )
    )

    # --------------------------------------------------------
    # The temporary column is no longer needed.
    # --------------------------------------------------------

    panel = panel.drop(
        columns=["demand_previous_hour"]
    )

    return panel


# ============================================================
# TARGET CONSTRUCTION
# ============================================================

def create_target(
    panel: pd.DataFrame,
) -> pd.DataFrame:
    """
    Create the next-hour forecasting target.

    For station S at hour t:

        next_hour_demand(t)
        =
        charging_demand(t + 1 hour)

    The target is generated separately for every station.
    """

    panel = panel.copy()

    panel = panel.sort_values(
        [
            "station_id",
            "hour",
        ]
    ).reset_index(drop=True)

    panel["next_hour_demand"] = (
        panel.groupby(
            "station_id",
            sort=False,
        )["charging_demand"]
        .shift(-1)
    )

    return panel


# ============================================================
# COMPLETE FEATURE ENGINEERING PIPELINE
# ============================================================

def build_forecasting_dataset() -> pd.DataFrame:
    """
    Execute the complete forecasting dataset pipeline.

    Steps
    -----
    1. Load raw data
    2. Create station-hour panel
    3. Add calendar features
    4. Add historical lag features
    5. Add historical rolling features
    6. Create next-hour target

    Returns
    -------
    pd.DataFrame
        Complete station-hour forecasting dataset.
    """

    # Step 1
    df = load_prepared_data()

    # Step 2
    panel = create_hourly_station_panel(df)

    # Step 3
    panel = add_calendar_features(panel)

    # Step 4
    panel = add_lag_features(panel)

    # Step 5
    panel = add_rolling_features(panel)

    # Step 6
    panel = create_target(panel)

    return panel


# ============================================================
# MAIN VALIDATION
# ============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("EV CHARGING FORECASTING DATASET")
    print("=" * 60)

    # --------------------------------------------------------
    # Load raw data
    # --------------------------------------------------------

    raw = load_prepared_data()

    print("\nRaw data:")
    print(
        f"Rows    : {len(raw):,}"
    )

    print(
        f"Columns : {len(raw.columns)}"
    )

    # --------------------------------------------------------
    # Build forecasting dataset
    # --------------------------------------------------------

    panel = build_forecasting_dataset()

    print("\nStation-hour panel:")

    print(
        f"Rows    : {len(panel):,}"
    )

    print(
        f"Columns : {len(panel.columns)}"
    )

    # --------------------------------------------------------
    # Station count
    # --------------------------------------------------------

    print("\nStations:")

    print(
        panel["station_id"].nunique()
    )

    # --------------------------------------------------------
    # Hour range
    # --------------------------------------------------------

    print("\nHour range:")

    print(
        panel["hour"].min()
    )

    print(
        panel["hour"].max()
    )

    # --------------------------------------------------------
    # Target statistics
    # --------------------------------------------------------

    print("\nTarget:")

    print(
        panel["next_hour_demand"].describe()
    )

    # --------------------------------------------------------
    # Target missing values
    # --------------------------------------------------------

    print("\nMissing values in target:")

    print(
        panel["next_hour_demand"].isna().sum()
    )

    # --------------------------------------------------------
    # Important feature missing values
    # --------------------------------------------------------

    print("\nMissing values in lag/rolling features:")

    feature_columns = [
        "demand_lag_1h",
        "demand_lag_2h",
        "demand_lag_3h",
        "demand_lag_24h",
        "station_load_lag_1h",
        "station_load_lag_24h",
        "queue_lag_1h",
        "queue_lag_24h",
        "demand_rolling_mean_3h",
        "demand_rolling_mean_6h",
        "demand_rolling_mean_24h",
    ]

    for column in feature_columns:

        print(
            f"{column:30} "
            f"{panel[column].isna().sum():,}"
        )

    # --------------------------------------------------------
    # Feature columns
    # --------------------------------------------------------

    print("\nFeature columns:")

    print(
        panel.columns.tolist()
    )

    # --------------------------------------------------------
    # Sample
    # --------------------------------------------------------

    print("\nSample:")

    sample_columns = [
        "station_id",
        "hour",
        "charging_demand",
        "demand_lag_1h",
        "demand_lag_24h",
        "demand_rolling_mean_24h",
        "next_hour_demand",
    ]

    print(
        panel[
            sample_columns
        ].head(30)
    )

    # --------------------------------------------------------
    # Final validation
    # --------------------------------------------------------

    print("\n" + "=" * 60)
    print("FEATURE ENGINEERING COMPLETE")
    print("=" * 60)