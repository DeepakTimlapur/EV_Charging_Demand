from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from sklearn.ensemble import (
    GradientBoostingRegressor,
    HistGradientBoostingRegressor,
    RandomForestRegressor,
)
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

TRAIN_PATH = PROJECT_ROOT / "outputs" / "train_data.csv"
VALIDATION_PATH = PROJECT_ROOT / "outputs" / "validation_data.csv"
TEST_PATH = PROJECT_ROOT / "outputs" / "test_data.csv"

MODEL_DIR = PROJECT_ROOT / "models"
REPORT_DIR = PROJECT_ROOT / "outputs" / "reports"
PREDICTION_DIR = PROJECT_ROOT / "outputs" / "predictions"


# ============================================================
# BASE FEATURES
# ============================================================

BASE_FEATURE_COLUMNS = [
    "hour_of_day",
    "day_of_week",
    "day_of_month",
    "month",
    "is_weekend",
    "demand_lag_1h",
    "demand_lag_2h",
    "demand_lag_3h",
    "demand_lag_24h",
    "station_load_lag_1h",
    "station_load_lag_24h",
    "queue_lag_1h",
    "queue_lag_24h",
    "demand_rolling_mean_3h",
    "demand_rolling_mean_6h",
    "demand_rolling_mean_24h",
]

TARGET_COLUMN = "next_hour_demand"

STATION_COLUMN = "station_id"


# ============================================================
# DATA LOADING
# ============================================================

def load_split(path: Path) -> pd.DataFrame:
    """
    Load a chronological split and retain rows with complete
    forecasting features and target.
    """

    if not path.exists():
        raise FileNotFoundError(
            f"Dataset split not found:\n{path}"
        )

    df = pd.read_csv(path)

    required_columns = (
        BASE_FEATURE_COLUMNS
        + [STATION_COLUMN, TARGET_COLUMN]
    )

    missing_columns = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing_columns:
        raise ValueError(
            "Missing required columns:\n"
            + "\n".join(missing_columns)
        )

    df = df.dropna(
        subset=required_columns
    ).copy()

    return df


# ============================================================
# FEATURE PREPARATION
# ============================================================

def prepare_features(
    train_df: pd.DataFrame,
    validation_df: pd.DataFrame,
    test_df: pd.DataFrame,
):
    """
    Prepare numeric features plus one-hot encoded station ID.

    The station categories are learned from the training set
    and then applied to validation and test.

    This avoids fitting the encoding using target information.
    """

    X_train = train_df[
        BASE_FEATURE_COLUMNS
        + [STATION_COLUMN]
    ].copy()

    X_validation = validation_df[
        BASE_FEATURE_COLUMNS
        + [STATION_COLUMN]
    ].copy()

    X_test = test_df[
        BASE_FEATURE_COLUMNS
        + [STATION_COLUMN]
    ].copy()

    # --------------------------------------------------------
    # One-hot encode station ID.
    #
    # Categories are derived only from the training set.
    # --------------------------------------------------------

    training_stations = sorted(
        X_train[STATION_COLUMN]
        .astype(str)
        .unique()
    )

    for df in [
        X_train,
        X_validation,
        X_test,
    ]:
        df[STATION_COLUMN] = (
            df[STATION_COLUMN]
            .astype(str)
            .astype(
                pd.CategoricalDtype(
                    categories=training_stations
                )
            )
        )

    X_train = pd.get_dummies(
        X_train,
        columns=[STATION_COLUMN],
        dtype=float,
    )

    X_validation = pd.get_dummies(
        X_validation,
        columns=[STATION_COLUMN],
        dtype=float,
    )

    X_test = pd.get_dummies(
        X_test,
        columns=[STATION_COLUMN],
        dtype=float,
    )

    # --------------------------------------------------------
    # Ensure all datasets have identical columns.
    # --------------------------------------------------------

    X_validation = X_validation.reindex(
        columns=X_train.columns,
        fill_value=0,
    )

    X_test = X_test.reindex(
        columns=X_train.columns,
        fill_value=0,
    )

    return (
        X_train,
        X_validation,
        X_test,
    )


# ============================================================
# METRICS
# ============================================================

def calculate_mape(
    y_true,
    y_pred,
):
    """
    Calculate supplementary MAPE.

    Zero actual values are excluded because MAPE is undefined
    when the actual value is zero.
    """

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    non_zero = y_true != 0

    if not np.any(non_zero):
        return np.nan

    return (
        np.mean(
            np.abs(
                (
                    y_true[non_zero]
                    - y_pred[non_zero]
                )
                / y_true[non_zero]
            )
        )
        * 100
    )


def calculate_metrics(
    y_true,
    y_pred,
):
    """
    Calculate regression metrics.
    """

    mae = mean_absolute_error(
        y_true,
        y_pred,
    )

    rmse = np.sqrt(
        mean_squared_error(
            y_true,
            y_pred,
        )
    )

    r2 = r2_score(
        y_true,
        y_pred,
    )

    mape = calculate_mape(
        y_true,
        y_pred,
    )

    return {
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
        "MAPE": mape,
    }


# ============================================================
# MODELS
# ============================================================

def create_models():
    """
    Create V2 candidate models.
    """

    return {
        "Linear Regression": LinearRegression(),

        "Random Forest": RandomForestRegressor(
            n_estimators=300,
            random_state=42,
            n_jobs=-1,
            min_samples_leaf=2,
        ),

        "Gradient Boosting": GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.05,
            max_depth=3,
            random_state=42,
        ),

        "HistGradientBoosting": HistGradientBoostingRegressor(
            max_iter=200,
            learning_rate=0.05,
            max_leaf_nodes=31,
            random_state=42,
        ),
    }


# ============================================================
# EVALUATION
# ============================================================

def evaluate_model(
    model_name,
    split_name,
    y_true,
    y_pred,
):
    """
    Return a standard evaluation record.
    """

    metrics = calculate_metrics(
        y_true,
        y_pred,
    )

    return {
        "Model": model_name,
        "Split": split_name,
        "MAE": metrics["MAE"],
        "RMSE": metrics["RMSE"],
        "R2": metrics["R2"],
        "MAPE": metrics["MAPE"],
    }


# ============================================================
# BASELINES
# ============================================================

def evaluate_baselines(
    validation_df,
    test_df,
):
    """
    Evaluate the same naive baselines used in V1.

    Baselines do not use station one-hot encoding because
    they are simple historical forecasting rules.
    """

    results_validation = []
    results_test = []

    # --------------------------------------------------------
    # Previous hour
    # --------------------------------------------------------

    validation_pred = validation_df[
        "demand_lag_1h"
    ].to_numpy()

    result = evaluate_model(
        "Previous Hour",
        "Validation",
        validation_df[TARGET_COLUMN].to_numpy(),
        validation_pred,
    )

    results_validation.append(result)

    test_pred = test_df[
        "demand_lag_1h"
    ].to_numpy()

    result = evaluate_model(
        "Previous Hour",
        "Test",
        test_df[TARGET_COLUMN].to_numpy(),
        test_pred,
    )

    results_test.append(result)

    # --------------------------------------------------------
    # Previous day
    # --------------------------------------------------------

    validation_pred = validation_df[
        "demand_lag_24h"
    ].to_numpy()

    result = evaluate_model(
        "Previous Day",
        "Validation",
        validation_df[TARGET_COLUMN].to_numpy(),
        validation_pred,
    )

    results_validation.append(result)

    test_pred = test_df[
        "demand_lag_24h"
    ].to_numpy()

    result = evaluate_model(
        "Previous Day",
        "Test",
        test_df[TARGET_COLUMN].to_numpy(),
        test_pred,
    )

    results_test.append(result)

    return (
        results_validation,
        results_test,
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 60)
    print("EV CHARGING DEMAND - STATION ID MODEL EXPERIMENT")
    print("=" * 60)

    # --------------------------------------------------------
    # Create directories
    # --------------------------------------------------------

    MODEL_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    REPORT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    PREDICTION_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------

    print("\nLoading datasets...")

    train_df = load_split(
        TRAIN_PATH
    )

    validation_df = load_split(
        VALIDATION_PATH
    )

    test_df = load_split(
        TEST_PATH
    )

    print(
        f"Train      : {len(train_df):,} rows"
    )

    print(
        f"Validation : {len(validation_df):,} rows"
    )

    print(
        f"Test       : {len(test_df):,} rows"
    )

    print(
        f"Stations   : "
        f"{train_df[STATION_COLUMN].nunique()}"
    )

    # --------------------------------------------------------
    # Prepare features
    # --------------------------------------------------------

    print("\nPreparing station-ID features...")

    (
        X_train,
        X_validation,
        X_test,
    ) = prepare_features(
        train_df,
        validation_df,
        test_df,
    )

    y_train = train_df[
        TARGET_COLUMN
    ]

    y_validation = validation_df[
        TARGET_COLUMN
    ]

    y_test = test_df[
        TARGET_COLUMN
    ]

    print(
        f"Base features           : "
        f"{len(BASE_FEATURE_COLUMNS)}"
    )

    print(
        f"Station one-hot columns : "
        f"{len(X_train.columns) - len(BASE_FEATURE_COLUMNS)}"
    )

    print(
        f"Total model features    : "
        f"{len(X_train.columns)}"
    )

    print(
        f"Train missing values    : "
        f"{X_train.isna().sum().sum()}"
    )

    print(
        f"Validation missing      : "
        f"{X_validation.isna().sum().sum()}"
    )

    print(
        f"Test missing            : "
        f"{X_test.isna().sum().sum()}"
    )

    # ========================================================
    # BASELINES
    # ========================================================

    (
        baseline_validation,
        baseline_test,
    ) = evaluate_baselines(
        validation_df,
        test_df,
    )

    # ========================================================
    # TRAIN MODELS
    # ========================================================

    models = create_models()

    validation_results = []

    trained_models = {}

    print("\n" + "=" * 60)
    print("V2 MODEL TRAINING")
    print("=" * 60)

    for model_name, model in models.items():

        print(
            f"\nTraining: {model_name}"
        )

        model.fit(
            X_train,
            y_train,
        )

        predictions = model.predict(
            X_validation
        )

        result = evaluate_model(
            model_name,
            "Validation",
            y_validation.to_numpy(),
            predictions,
        )

        validation_results.append(
            result
        )

        trained_models[
            model_name
        ] = model

        print(
            f"MAE  : {result['MAE']:.4f}"
        )

        print(
            f"RMSE : {result['RMSE']:.4f}"
        )

        print(
            f"R²   : {result['R2']:.4f}"
        )

        print(
            f"MAPE : {result['MAPE']:.2f}%"
        )

    # ========================================================
    # VALIDATION RESULTS
    # ========================================================

    validation_df_results = pd.DataFrame(
        validation_results
        + baseline_validation
    )

    validation_df_results = (
        validation_df_results
        .sort_values("MAE")
        .reset_index(drop=True)
    )

    print("\n" + "=" * 60)
    print("V2 VALIDATION RESULTS")
    print("=" * 60)

    print(
        validation_df_results.to_string(
            index=False
        )
    )

    # --------------------------------------------------------
    # Select V2 model using validation MAE.
    # --------------------------------------------------------

    ml_validation = pd.DataFrame(
        validation_results
    ).sort_values(
        "MAE"
    )

    selected_model_name = (
        ml_validation.iloc[0]["Model"]
    )

    selected_model = trained_models[
        selected_model_name
    ]

    print("\n" + "=" * 60)
    print("V2 SELECTED MODEL")
    print("=" * 60)

    print(
        f"Model: {selected_model_name}"
    )

    print(
        "Selection criterion: "
        "lowest validation MAE"
    )

    # ========================================================
    # FINAL TEST
    # ========================================================

    test_predictions = selected_model.predict(
        X_test
    )

    selected_test_result = evaluate_model(
        selected_model_name,
        "Test",
        y_test.to_numpy(),
        test_predictions,
    )

    test_results = pd.DataFrame(
        baseline_test
        + [selected_test_result]
    )

    print("\n" + "=" * 60)
    print("V2 FINAL TEST RESULTS")
    print("=" * 60)

    print(
        test_results.to_string(
            index=False
        )
    )

    # ========================================================
    # V1 VS V2 COMPARISON
    # ========================================================

    print("\n" + "=" * 60)
    print("V1 VS V2 COMPARISON")
    print("=" * 60)

    comparison = pd.DataFrame(
        [
            {
                "Version": "V1",
                "Model": "Gradient Boosting",
                "Features": 16,
                "Test MAE": 16.065038,
                "Test RMSE": 23.460165,
                "Test R2": 0.036521,
            },
            {
                "Version": "V2",
                "Model": selected_model_name,
                "Features": len(X_train.columns),
                "Test MAE": selected_test_result["MAE"],
                "Test RMSE": selected_test_result["RMSE"],
                "Test R2": selected_test_result["R2"],
            },
        ]
    )

    print(
        comparison.to_string(
            index=False
        )
    )

    # ========================================================
    # SAVE V2 MODEL
    # ========================================================

    v2_model_path = (
        MODEL_DIR
        / "station_id_model.joblib"
    )

    joblib.dump(
        selected_model,
        v2_model_path,
    )

    # --------------------------------------------------------
    # Save feature column names.
    # --------------------------------------------------------

    feature_columns_path = (
        MODEL_DIR
        / "station_id_feature_columns.joblib"
    )

    joblib.dump(
        list(X_train.columns),
        feature_columns_path,
    )

    # ========================================================
    # SAVE TEST PREDICTIONS
    # ========================================================

    prediction_output = test_df[
        [
            "station_id",
            "hour",
            TARGET_COLUMN,
        ]
    ].copy()

    prediction_output[
        "prediction"
    ] = test_predictions

    prediction_output[
        "absolute_error"
    ] = np.abs(
        prediction_output[TARGET_COLUMN]
        - prediction_output["prediction"]
    )

    prediction_path = (
        PREDICTION_DIR
        / "station_id_test_predictions.csv"
    )

    prediction_output.to_csv(
        prediction_path,
        index=False,
    )

    # ========================================================
    # SAVE RESULTS
    # ========================================================

    validation_output_path = (
        REPORT_DIR
        / "station_id_validation_results.csv"
    )

    validation_df_results.to_csv(
        validation_output_path,
        index=False,
    )

    test_output_path = (
        REPORT_DIR
        / "station_id_test_results.csv"
    )

    test_results.to_csv(
        test_output_path,
        index=False,
    )

    comparison_path = (
        REPORT_DIR
        / "v1_vs_v2_comparison.csv"
    )

    comparison.to_csv(
        comparison_path,
        index=False,
    )

    # ========================================================
    # FEATURE IMPORTANCE
    # ========================================================

    if hasattr(
        selected_model,
        "feature_importances_",
    ):

        importance_df = pd.DataFrame(
            {
                "feature": X_train.columns,
                "importance": (
                    selected_model
                    .feature_importances_
                ),
            }
        )

        importance_df = (
            importance_df
            .sort_values(
                "importance",
                ascending=False,
            )
            .reset_index(drop=True)
        )

        importance_path = (
            REPORT_DIR
            / "station_id_feature_importance.csv"
        )

        importance_df.to_csv(
            importance_path,
            index=False,
        )

        print("\nV2 feature importance:")

        print(
            importance_df.head(20).to_string(
                index=False
            )
        )

    # ========================================================
    # FINAL
    # ========================================================

    print("\n" + "=" * 60)
    print("STATION-ID EXPERIMENT COMPLETE")
    print("=" * 60)

    print(
        f"\nV2 model saved:\n"
        f"{v2_model_path}"
    )

    print(
        f"\nComparison saved:\n"
        f"{comparison_path}"
    )

    print(
        f"\nV2 test results saved:\n"
        f"{test_output_path}"
    )


if __name__ == "__main__":
    main()