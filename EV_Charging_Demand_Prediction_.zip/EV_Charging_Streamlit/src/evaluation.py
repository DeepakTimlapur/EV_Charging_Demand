from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

PREDICTIONS_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "predictions"
    / "test_predictions.csv"
)

VALIDATION_RESULTS_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "reports"
    / "validation_results.csv"
)

TEST_RESULTS_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "reports"
    / "test_results.csv"
)

FEATURE_IMPORTANCE_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "reports"
    / "feature_importance.csv"
)

FIGURES_DIR = (
    PROJECT_ROOT
    / "outputs"
    / "figures"
)


# ============================================================
# SETUP
# ============================================================

def setup():
    FIGURES_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )


# ============================================================
# LOAD TEST PREDICTIONS
# ============================================================

def load_predictions():

    if not PREDICTIONS_PATH.exists():
        raise FileNotFoundError(
            f"Prediction file not found:\n"
            f"{PREDICTIONS_PATH}"
        )

    df = pd.read_csv(
        PREDICTIONS_PATH
    )

    df["hour"] = pd.to_datetime(
        df["hour"]
    )

    return df


# ============================================================
# 1. ACTUAL VS PREDICTED
# ============================================================

def plot_actual_vs_predicted(
    df: pd.DataFrame,
):

    # Aggregate across stations so the chart shows
    # total station-level demand for each hour.

    hourly = (
        df.groupby("hour")
        .agg(
            actual_demand=(
                "next_hour_demand",
                "sum",
            ),
            predicted_demand=(
                "prediction",
                "sum",
            ),
        )
        .reset_index()
    )

    plt.figure(
        figsize=(14, 6)
    )

    plt.plot(
        hourly["hour"],
        hourly["actual_demand"],
        label="Actual Demand",
        linewidth=2,
    )

    plt.plot(
        hourly["hour"],
        hourly["predicted_demand"],
        label="Predicted Demand",
        linewidth=2,
    )

    plt.xlabel(
        "Time"
    )

    plt.ylabel(
        "Charging Demand"
    )

    plt.title(
        "Actual vs Predicted EV Charging Demand"
    )

    plt.legend()

    plt.xticks(
        rotation=45
    )

    plt.tight_layout()

    output_path = (
        FIGURES_DIR
        / "actual_vs_predicted.png"
    )

    plt.savefig(
        output_path,
        dpi=200,
        bbox_inches="tight",
    )

    plt.close()

    print(
        f"Saved: {output_path}"
    )


# ============================================================
# 2. PREDICTION ERROR DISTRIBUTION
# ============================================================

def plot_error_distribution(
    df: pd.DataFrame,
):

    df = df.copy()

    df["error"] = (
        df["next_hour_demand"]
        - df["prediction"]
    )

    plt.figure(
        figsize=(10, 6)
    )

    sns.histplot(
        df["error"],
        bins=50,
        kde=True,
    )

    plt.axvline(
        0,
        linestyle="--",
        linewidth=2,
    )

    plt.xlabel(
        "Prediction Error"
    )

    plt.ylabel(
        "Frequency"
    )

    plt.title(
        "Prediction Error Distribution"
    )

    plt.tight_layout()

    output_path = (
        FIGURES_DIR
        / "prediction_error_distribution.png"
    )

    plt.savefig(
        output_path,
        dpi=200,
        bbox_inches="tight",
    )

    plt.close()

    print(
        f"Saved: {output_path}"
    )


# ============================================================
# 3. ACTUAL VS PREDICTED SCATTER
# ============================================================

def plot_actual_predicted_scatter(
    df: pd.DataFrame,
):

    plt.figure(
        figsize=(8, 8)
    )

    plt.scatter(
        df["next_hour_demand"],
        df["prediction"],
        alpha=0.25,
        s=15,
    )

    maximum = max(
        df["next_hour_demand"].max(),
        df["prediction"].max(),
    )

    plt.plot(
        [0, maximum],
        [0, maximum],
        linestyle="--",
        linewidth=2,
    )

    plt.xlabel(
        "Actual Demand"
    )

    plt.ylabel(
        "Predicted Demand"
    )

    plt.title(
        "Actual vs Predicted Demand"
    )

    plt.tight_layout()

    output_path = (
        FIGURES_DIR
        / "actual_predicted_scatter.png"
    )

    plt.savefig(
        output_path,
        dpi=200,
        bbox_inches="tight",
    )

    plt.close()

    print(
        f"Saved: {output_path}"
    )


# ============================================================
# 4. FEATURE IMPORTANCE
# ============================================================

def plot_feature_importance():

    if not FEATURE_IMPORTANCE_PATH.exists():
        print(
            "Feature importance file not found."
        )
        return

    df = pd.read_csv(
        FEATURE_IMPORTANCE_PATH
    )

    df = (
        df.sort_values(
            "importance",
            ascending=True,
        )
    )

    plt.figure(
        figsize=(10, 8)
    )

    plt.barh(
        df["feature"],
        df["importance"],
    )

    plt.xlabel(
        "Importance"
    )

    plt.ylabel(
        "Feature"
    )

    plt.title(
        "Gradient Boosting Feature Importance"
    )

    plt.tight_layout()

    output_path = (
        FIGURES_DIR
        / "feature_importance.png"
    )

    plt.savefig(
        output_path,
        dpi=200,
        bbox_inches="tight",
    )

    plt.close()

    print(
        f"Saved: {output_path}"
    )


# ============================================================
# 5. MODEL COMPARISON
# ============================================================

def plot_model_comparison():

    if not VALIDATION_RESULTS_PATH.exists():
        raise FileNotFoundError(
            "Validation results not found."
        )

    df = pd.read_csv(
        VALIDATION_RESULTS_PATH
    )

    df = df.sort_values(
        "MAE"
    )

    plt.figure(
        figsize=(10, 6)
    )

    plt.bar(
        df["Model"],
        df["MAE"],
    )

    plt.ylabel(
        "MAE"
    )

    plt.xlabel(
        "Model"
    )

    plt.title(
        "Validation MAE Comparison"
    )

    plt.xticks(
        rotation=30,
        ha="right",
    )

    plt.tight_layout()

    output_path = (
        FIGURES_DIR
        / "model_comparison_mae.png"
    )

    plt.savefig(
        output_path,
        dpi=200,
        bbox_inches="tight",
    )

    plt.close()

    print(
        f"Saved: {output_path}"
    )


# ============================================================
# 6. STATION-LEVEL ERROR
# ============================================================

def calculate_station_errors(
    df: pd.DataFrame,
):

    station_errors = (
        df.groupby("station_id")
        .agg(
            actual_demand=(
                "next_hour_demand",
                "mean",
            ),
            predicted_demand=(
                "prediction",
                "mean",
            ),
            mean_absolute_error=(
                "absolute_error",
                "mean",
            ),
            observations=(
                "station_id",
                "size",
            ),
        )
        .reset_index()
        .sort_values(
            "mean_absolute_error",
            ascending=False,
        )
    )

    output_path = (
        PROJECT_ROOT
        / "outputs"
        / "reports"
        / "station_error_analysis.csv"
    )

    station_errors.to_csv(
        output_path,
        index=False,
    )

    print(
        f"Saved: {output_path}"
    )

    return station_errors


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 60)
    print("EV CHARGING MODEL EVALUATION")
    print("=" * 60)

    setup()

    predictions = load_predictions()

    print(
        f"\nTest prediction rows: "
        f"{len(predictions):,}"
    )

    # --------------------------------------------------------
    # Generate plots
    # --------------------------------------------------------

    print("\nGenerating evaluation plots...")

    plot_actual_vs_predicted(
        predictions
    )

    plot_error_distribution(
        predictions
    )

    plot_actual_predicted_scatter(
        predictions
    )

    plot_feature_importance()

    plot_model_comparison()

    # --------------------------------------------------------
    # Station analysis
    # --------------------------------------------------------

    station_errors = calculate_station_errors(
        predictions
    )

    print("\nStation error analysis:")

    print(
        station_errors.to_string(
            index=False
        )
    )

    print("\n" + "=" * 60)
    print("EVALUATION COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    main()