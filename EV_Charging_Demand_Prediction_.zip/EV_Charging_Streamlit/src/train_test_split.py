from pathlib import Path

import pandas as pd

from feature_engineering import build_forecasting_dataset


PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = PROJECT_ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)


def create_chronological_split(
    df: pd.DataFrame,
    train_ratio: float = 0.70,
    validation_ratio: float = 0.15,
):
    """
    Split forecasting observations chronologically.

    All stations belonging to the same hour remain in the
    same split. No random shuffling is performed.
    """

    df = df.copy()

    # Only rows with an observed next-hour target can be
    # used for supervised learning.
    df = df.dropna(
        subset=["next_hour_demand"]
    ).copy()

    # Determine split boundaries from unique global hours.
    unique_hours = (
        pd.Series(
            df["hour"].drop_duplicates()
        )
        .sort_values()
        .reset_index(drop=True)
    )

    n_hours = len(unique_hours)

    train_end = int(
        n_hours * train_ratio
    )

    validation_end = int(
        n_hours * (
            train_ratio + validation_ratio
        )
    )

    train_hours = set(
        unique_hours.iloc[:train_end]
    )

    validation_hours = set(
        unique_hours.iloc[
            train_end:validation_end
        ]
    )

    test_hours = set(
        unique_hours.iloc[
            validation_end:
        ]
    )

    train = df[
        df["hour"].isin(train_hours)
    ].copy()

    validation = df[
        df["hour"].isin(validation_hours)
    ].copy()

    test = df[
        df["hour"].isin(test_hours)
    ].copy()

    return train, validation, test, unique_hours


def print_split_info(
    name: str,
    df: pd.DataFrame,
):
    """Print information about a dataset split."""

    print(f"\n{name}")
    print("-" * 60)

    print(f"Rows          : {len(df):,}")
    print(
        f"Stations      : "
        f"{df['station_id'].nunique()}"
    )
    print(
        f"Unique hours  : "
        f"{df['hour'].nunique():,}"
    )

    print(
        f"Start         : "
        f"{df['hour'].min()}"
    )

    print(
        f"End           : "
        f"{df['hour'].max()}"
    )

    print(
        f"Target missing: "
        f"{df['next_hour_demand'].isna().sum()}"
    )


if __name__ == "__main__":

    print("=" * 60)
    print("CHRONOLOGICAL TRAIN / VALIDATION / TEST SPLIT")
    print("=" * 60)

    print("\nBuilding forecasting dataset...")

    df = build_forecasting_dataset()

    print(
        f"Full station-hour panel: "
        f"{len(df):,} rows"
    )

    print(
        f"Rows with valid target: "
        f"{df['next_hour_demand'].notna().sum():,}"
    )

    train, validation, test, unique_hours = (
        create_chronological_split(df)
    )

    print(
        f"\nTotal unique target hours: "
        f"{len(unique_hours):,}"
    )

    print_split_info(
        "TRAIN SET",
        train,
    )

    print_split_info(
        "VALIDATION SET",
        validation,
    )

    print_split_info(
        "TEST SET",
        test,
    )

    # Verify chronological ordering.
    print("\nChronological boundary checks")
    print("-" * 60)

    print(
        "Train end < Validation start:",
        train["hour"].max()
        < validation["hour"].min(),
    )

    print(
        "Validation end < Test start:",
        validation["hour"].max()
        < test["hour"].min(),
    )

    # Verify no overlapping hours.
    train_hours = set(train["hour"])
    validation_hours = set(validation["hour"])
    test_hours = set(test["hour"])

    print(
        "Train/Validation overlap:",
        bool(train_hours & validation_hours),
    )

    print(
        "Validation/Test overlap:",
        bool(validation_hours & test_hours),
    )

    print(
        "Train/Test overlap:",
        bool(train_hours & test_hours),
    )

    # Save split datasets for inspection.
    train.to_csv(
        OUTPUT_DIR / "train_data.csv",
        index=False,
    )

    validation.to_csv(
        OUTPUT_DIR / "validation_data.csv",
        index=False,
    )

    test.to_csv(
        OUTPUT_DIR / "test_data.csv",
        index=False,
    )

    print("\nSaved:")
    print(
        OUTPUT_DIR / "train_data.csv"
    )
    print(
        OUTPUT_DIR / "validation_data.csv"
    )
    print(
        OUTPUT_DIR / "test_data.csv"
    )

    print("\n" + "=" * 60)
    print("SPLIT COMPLETE")
    print("=" * 60)