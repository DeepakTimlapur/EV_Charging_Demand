from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "EV_Charging_Demand_Dataset_Full.csv"


def load_raw_data() -> pd.DataFrame:
    """Load the raw EV charging dataset."""
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")

    return pd.read_csv(DATA_PATH)


def convert_datetime_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert timestamp-related columns from strings to datetime.
    """
    df = df.copy()

    datetime_columns = [
        "timestamp",
        "arrival_time",
        "charging_start_time",
        "charging_end_time",
    ]

    for column in datetime_columns:
        if column in df.columns:
            df[column] = pd.to_datetime(
                df[column],
                errors="coerce"
            )

    return df


def check_datetime_conversion(df: pd.DataFrame) -> dict:
    """Check whether datetime conversion introduced invalid values."""

    datetime_columns = [
        "timestamp",
        "arrival_time",
        "charging_start_time",
        "charging_end_time",
    ]

    result = {}

    for column in datetime_columns:
        if column in df.columns:
            result[column] = int(df[column].isna().sum())

    return result


def preprocess_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Apply basic preprocessing without changing the modeling features.

    Important:
    This function does not perform imputation, feature engineering,
    aggregation, or target construction.
    """

    df = df.copy()

    # Convert datetime fields
    df = convert_datetime_columns(df)

    # Sort chronologically
    df = df.sort_values(
        ["timestamp", "station_id"]
    ).reset_index(drop=True)

    return df


if __name__ == "__main__":

    print("=" * 60)
    print("EV CHARGING DATA PREPROCESSING")
    print("=" * 60)

    df = load_raw_data()

    print(f"\nRaw shape: {df.shape}")

    df = preprocess_data(df)

    print(f"Processed shape: {df.shape}")

    print("\nDatetime validation:")

    datetime_check = check_datetime_conversion(df)

    for column, invalid_count in datetime_check.items():
        print(f"{column:25} invalid: {invalid_count}")

    print("\nData types after preprocessing:")

    for column in [
        "timestamp",
        "arrival_time",
        "charging_start_time",
        "charging_end_time",
    ]:
        print(f"{column:25} {df[column].dtype}")

    print("\nFirst 5 timestamps:")
    print(df["timestamp"].head().to_string(index=False))

    print("\nLast 5 timestamps:")
    print(df["timestamp"].tail().to_string(index=False))

    print("\nFinal shape:")
    print(df.shape)

    print("\n" + "=" * 60)
    print("PREPROCESSING VALIDATION COMPLETE")
    print("=" * 60)