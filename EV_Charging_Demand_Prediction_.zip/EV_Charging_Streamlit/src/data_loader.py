from pathlib import Path

import pandas as pd


# Project root:
# EV_Charging_Streamlit/
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Raw dataset location
DATA_PATH = PROJECT_ROOT / "data" / "EV_Charging_Demand_Dataset_Full.csv"


def load_data() -> pd.DataFrame:
    """
    Load the raw EV charging dataset.

    Returns
    -------
    pd.DataFrame
        Raw dataset loaded from CSV.
    """
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found at: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)

    return df


def validate_data(df: pd.DataFrame) -> dict:
    """
    Perform basic validation checks on the raw dataset.

    Parameters
    ----------
    df : pd.DataFrame
        Dataset to validate.

    Returns
    -------
    dict
        Validation results.
    """

    validation = {
        "rows": len(df),
        "columns": len(df.columns),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_values": int(df.isna().sum().sum()),
        "station_count": int(df["station_id"].nunique()),
        "vehicle_count": int(df["vehicle_id"].nunique()),
    }

    return validation


if __name__ == "__main__":
    print("=" * 60)
    print("EV CHARGING DEMAND DATA VALIDATION")
    print("=" * 60)

    print(f"\nDataset path:\n{DATA_PATH}")

    df = load_data()

    print("\nDataset loaded successfully.")

    print(f"\nRows    : {df.shape[0]}")
    print(f"Columns : {df.shape[1]}")

    print("\nColumn names:")
    for i, column in enumerate(df.columns, start=1):
        print(f"{i:2}. {column}")

    validation = validate_data(df)

    print("\nValidation results:")
    print(f"Duplicate rows : {validation['duplicate_rows']}")
    print(f"Missing values : {validation['missing_values']}")
    print(f"Stations       : {validation['station_count']}")
    print(f"Vehicles       : {validation['vehicle_count']}")

    print("\nTimestamp range:")

    timestamp = pd.to_datetime(df["timestamp"], errors="coerce")

    print(f"Minimum timestamp : {timestamp.min()}")
    print(f"Maximum timestamp : {timestamp.max()}")

    print("\nData types:")
    print(df.dtypes)

    print("\nFirst 5 rows:")
    print(df.head())

    print("\n" + "=" * 60)
    print("VALIDATION COMPLETE")
    print("=" * 60)