from pathlib import Path

import joblib
import pandas as pd


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "selected_model.joblib"
)

TRAIN_DATA_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "train_data.csv"
)

VALIDATION_DATA_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "validation_data.csv"
)

TEST_DATA_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "test_data.csv"
)


# ============================================================
# MODEL FEATURES
# ============================================================

FEATURE_COLUMNS = [
    "hour_of_day",
    "day_of_week",
    "day_of_month",
    "month",
    "is_weekend",
    "demand_lag_1h",
    "demand_lag_2h",
    "demand_lag_3h",
    "demand_lag_24h",
    "station_load_lag_1h",
    "station_load_lag_24h",
    "queue_lag_1h",
    "queue_lag_24h",
    "demand_rolling_mean_3h",
    "demand_rolling_mean_6h",
    "demand_rolling_mean_24h",
]

TARGET_COLUMN = "next_hour_demand"


# ============================================================
# MODEL LOADING
# ============================================================

def load_model():
    """
    Load the final V1 Gradient Boosting model.
    """

    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"Model not found:\n{MODEL_PATH}"
        )

    return joblib.load(
        MODEL_PATH
    )


# ============================================================
# LOAD FORECASTING DATA
# ============================================================

def load_forecasting_data():
    """
    Load the complete model-ready chronological datasets.
    """

    paths = [
        TRAIN_DATA_PATH,
        VALIDATION_DATA_PATH,
        TEST_DATA_PATH,
    ]

    frames = []

    for path in paths:

        if not path.exists():
            raise FileNotFoundError(
                f"Required dataset not found:\n{path}"
            )

        frame = pd.read_csv(
            path
        )

        frames.append(
            frame
        )

    data = pd.concat(
        frames,
        ignore_index=True,
    )

    data["hour"] = pd.to_datetime(
        data["hour"]
    )

    data = (
        data
        .sort_values(
            [
                "station_id",
                "hour",
            ]
        )
        .reset_index(drop=True)
    )

    return data


# ============================================================
# AVAILABLE STATIONS
# ============================================================

def get_available_stations(
    data: pd.DataFrame,
):
    """
    Return sorted station IDs.
    """

    return sorted(
        data["station_id"]
        .dropna()
        .unique()
        .tolist()
    )


# ============================================================
# AVAILABLE FORECAST TIMES
# ============================================================

def get_station_history(
    data: pd.DataFrame,
    station_id: str,
):
    """
    Return all available observations for a station.
    """

    station_data = (
        data[
            data["station_id"]
            == station_id
        ]
        .copy()
        .sort_values("hour")
        .reset_index(drop=True)
    )

    return station_data


# ============================================================
# LATEST AVAILABLE OBSERVATION
# ============================================================

def get_latest_observation(
    data: pd.DataFrame,
    station_id: str,
):
    """
    Return the latest model-ready observation for a station.
    """

    station_data = get_station_history(
        data,
        station_id,
    )

    if station_data.empty:
        return None

    # Only retain rows with complete model features.
    station_data = station_data.dropna(
        subset=FEATURE_COLUMNS
    )

    if station_data.empty:
        return None

    return station_data.iloc[-1]


# ============================================================
# FORECAST NEXT HOUR
# ============================================================

def forecast_next_hour(
    model,
    data: pd.DataFrame,
    station_id: str,
):
    """
    Generate a next-hour demand forecast for one station.

    The prediction uses the latest available historical
    feature vector for that station.
    """

    latest = get_latest_observation(
        data,
        station_id,
    )

    if latest is None:
        raise ValueError(
            f"No complete forecasting history "
            f"is available for station {station_id}."
        )

    X = pd.DataFrame(
        [
            latest[FEATURE_COLUMNS]
        ],
        columns=FEATURE_COLUMNS,
    )

    prediction = model.predict(
        X
    )[0]

    # Demand cannot be negative.
    prediction = max(
        0.0,
        float(prediction),
    )

    forecast_time = (
        latest["hour"]
        + pd.Timedelta(hours=1)
    )

    return {
        "station_id": station_id,
        "latest_observation": latest["hour"],
        "forecast_time": forecast_time,
        "predicted_demand": prediction,
    }


# ============================================================
# HISTORICAL STATION SUMMARY
# ============================================================

def station_summary(
    data: pd.DataFrame,
    station_id: str,
):
    """
    Generate useful historical statistics for a station.
    """

    station_data = get_station_history(
        data,
        station_id,
    )

    if station_data.empty:
        return {}

    demand = station_data[
        "charging_demand"
    ]

    summary = {
        "average_demand": float(
            demand.mean()
        ),
        "maximum_demand": float(
            demand.max()
        ),
        "minimum_demand": float(
            demand.min()
        ),
        "median_demand": float(
            demand.median()
        ),
        "observations": int(
            len(station_data)
        ),
    }

    return summary


# ============================================================
# HISTORICAL HOURLY PROFILE
# ============================================================

def hourly_profile(
    data: pd.DataFrame,
    station_id: str,
):
    """
    Calculate the historical average demand by hour of day.
    """

    station_data = get_station_history(
        data,
        station_id,
    )

    if station_data.empty:
        return pd.DataFrame()

    profile = (
        station_data
        .groupby("hour_of_day")
        .agg(
            average_demand=(
                "charging_demand",
                "mean",
            ),
            observations=(
                "charging_demand",
                "size",
            ),
        )
        .reset_index()
    )

    return profile


# ============================================================
# RECENT DEMAND HISTORY
# ============================================================

def recent_demand(
    data: pd.DataFrame,
    station_id: str,
    periods: int = 24,
):
    """
    Return the most recent station demand observations.
    """

    station_data = get_station_history(
        data,
        station_id,
    )

    if station_data.empty:
        return pd.DataFrame()

    recent = station_data[
        [
            "hour",
            "charging_demand",
            "queue_length",
            "station_load",
        ]
    ].tail(
        periods
    )

    return recent.reset_index(
        drop=True
    )


# ============================================================
# SIMPLE DEMAND CATEGORY
# ============================================================

def classify_demand(
    predicted_demand: float,
):
    """
    Convert predicted demand into an operational category.

    Thresholds are descriptive dashboard categories,
    not model classes.
    """

    if predicted_demand < 20:
        return "Low"

    if predicted_demand < 60:
        return "Moderate"

    if predicted_demand < 80:
        return "High"

    return "Very High"


# ============================================================
# MAIN TEST
# ============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("EV CHARGING FORECASTING MODULE")
    print("=" * 60)

    # --------------------------------------------------------
    # Load model
    # --------------------------------------------------------

    model = load_model()

    print(
        "\nModel loaded successfully."
    )

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------

    data = load_forecasting_data()

    print(
        f"Rows loaded: {len(data):,}"
    )

    # --------------------------------------------------------
    # Stations
    # --------------------------------------------------------

    stations = get_available_stations(
        data
    )

    print(
        f"Stations available: {len(stations)}"
    )

    print(
        stations
    )

    # --------------------------------------------------------
    # Test forecast using first station
    # --------------------------------------------------------

    station_id = stations[0]

    forecast = forecast_next_hour(
        model,
        data,
        station_id,
    )

    print("\nForecast:")

    print(
        f"Station:"
        f" {forecast['station_id']}"
    )

    print(
        f"Latest observation:"
        f" {forecast['latest_observation']}"
    )

    print(
        f"Forecast time:"
        f" {forecast['forecast_time']}"
    )

    print(
        f"Predicted demand:"
        f" {forecast['predicted_demand']:.2f}"
    )

    print(
        f"Demand category:"
        f" {classify_demand(forecast['predicted_demand'])}"
    )

    # --------------------------------------------------------
    # Summary
    # --------------------------------------------------------

    summary = station_summary(
        data,
        station_id,
    )

    print("\nStation summary:")

    for key, value in summary.items():

        print(
            f"{key}: {value}"
        )

    print("\n" + "=" * 60)
    print("FORECASTING MODULE TEST COMPLETE")
    print("=" * 60)