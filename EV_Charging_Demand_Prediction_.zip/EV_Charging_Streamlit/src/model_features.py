from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = PROJECT_ROOT / "outputs"


# Only features that are available from historical information
# or known calendar information at prediction time.
FEATURE_COLUMNS = [
    "hour_of_day",
    "day_of_week",
    "day_of_month",
    "month",
    "is_weekend",

    "demand_lag_1h",
    "demand_lag_2h",
    "demand_lag_3h",
    "demand_lag_24h",

    "station_load_lag_1h",
    "station_load_lag_24h",

    "queue_lag_1h",
    "queue_lag_24h",

    "demand_rolling_mean_3h",
    "demand_rolling_mean_6h",
    "demand_rolling_mean_24h",
]


TARGET_COLUMN = "next_hour_demand"


FORBIDDEN_CONTEMPORANEOUS_COLUMNS = [
    "charging_demand",
    "station_load",
    "queue_length",
    "energy_consumed_kWh",
    "waiting_time",
]


def load_split(filename: str) -> pd.DataFrame:
    """Load one previously generated split."""

    path = OUTPUT_DIR / filename

    if not path.exists():
        raise FileNotFoundError(
            f"Split file not found: {path}"
        )

    return pd.read_csv(
        path,
        parse_dates=["hour"],
    )


def validate_feature_columns(df: pd.DataFrame) -> None:
    """Verify that the requested feature columns exist."""

    missing = [
        column
        for column in FEATURE_COLUMNS
        if column not in df.columns
    ]

    if missing:
        raise ValueError(
            f"Missing feature columns: {missing}"
        )


def validate_no_direct_leakage() -> None:
    """Verify forbidden contemporaneous columns are not features."""

    leakage_columns = set(FEATURE_COLUMNS).intersection(
        FORBIDDEN_CONTEMPORANEOUS_COLUMNS
    )

    if leakage_columns:
        raise ValueError(
            "Potential leakage columns detected: "
            f"{sorted(leakage_columns)}"
        )


def prepare_model_data(
    df: pd.DataFrame,
):
    """
    Prepare X and y for model training/evaluation.

    Rows with missing model features are removed.
    The target must always be present.
    """

    validate_feature_columns(df)

    X = df[FEATURE_COLUMNS].copy()
    y = df[TARGET_COLUMN].copy()

    valid_rows = (
        X.notna().all(axis=1)
        & y.notna()
    )

    X = X.loc[valid_rows].reset_index(drop=True)
    y = y.loc[valid_rows].reset_index(drop=True)

    return X, y


if __name__ == "__main__":

    print("=" * 60)
    print("LEAKAGE-SAFE MODEL FEATURE VALIDATION")
    print("=" * 60)

    validate_no_direct_leakage()

    print("\nNo forbidden contemporaneous columns detected.")

    print("\nModel features:")
    for index, column in enumerate(
        FEATURE_COLUMNS,
        start=1,
    ):
        print(f"{index:2}. {column}")

    for split_name, filename in [
        ("TRAIN", "train_data.csv"),
        ("VALIDATION", "validation_data.csv"),
        ("TEST", "test_data.csv"),
    ]:

        print(f"\n{split_name} SET")
        print("-" * 60)

        df = load_split(filename)

        print(
            f"Original rows : {len(df):,}"
        )

        X, y = prepare_model_data(df)

        print(
            f"Usable rows   : {len(X):,}"
        )

        print(
            f"Removed rows  : "
            f"{len(df) - len(X):,}"
        )

        print(
            f"Features      : {X.shape[1]}"
        )

        print(
            f"Target values : {len(y):,}"
        )

        print(
            f"X missing     : "
            f"{int(X.isna().sum().sum())}"
        )

        print(
            f"y missing     : "
            f"{int(y.isna().sum())}"
        )

    print("\n" + "=" * 60)
    print("FEATURE VALIDATION COMPLETE")
    print("=" * 60)