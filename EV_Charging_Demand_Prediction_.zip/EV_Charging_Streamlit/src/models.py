from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from sklearn.ensemble import (
    GradientBoostingRegressor,
    HistGradientBoostingRegressor,
    RandomForestRegressor,
)
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

TRAIN_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "train_data.csv"
)

VALIDATION_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "validation_data.csv"
)

TEST_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "test_data.csv"
)

MODEL_DIR = (
    PROJECT_ROOT
    / "models"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "outputs"
)

REPORT_DIR = (
    OUTPUT_DIR
    / "reports"
)

PREDICTION_DIR = (
    OUTPUT_DIR
    / "predictions"
)


# ============================================================
# MODEL FEATURES
# ============================================================

FEATURE_COLUMNS = [
    "hour_of_day",
    "day_of_week",
    "day_of_month",
    "month",
    "is_weekend",
    "demand_lag_1h",
    "demand_lag_2h",
    "demand_lag_3h",
    "demand_lag_24h",
    "station_load_lag_1h",
    "station_load_lag_24h",
    "queue_lag_1h",
    "queue_lag_24h",
    "demand_rolling_mean_3h",
    "demand_rolling_mean_6h",
    "demand_rolling_mean_24h",
]

TARGET_COLUMN = "next_hour_demand"


# ============================================================
# DATA LOADING
# ============================================================

def load_split(path: Path) -> pd.DataFrame:
    """
    Load a chronological split and retain only rows with
    complete model features and target.
    """

    if not path.exists():
        raise FileNotFoundError(
            f"Split file not found:\n{path}"
        )

    df = pd.read_csv(path)

    missing_columns = [
        column
        for column in FEATURE_COLUMNS + [TARGET_COLUMN]
        if column not in df.columns
    ]

    if missing_columns:
        raise ValueError(
            "Missing required columns:\n"
            + "\n".join(missing_columns)
        )

    df = df.dropna(
        subset=FEATURE_COLUMNS + [TARGET_COLUMN]
    ).copy()

    return df


# ============================================================
# METRICS
# ============================================================

def calculate_mape(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> float:
    """
    Calculate MAPE while excluding zero actual values.

    MAPE is supplementary because the target contains many
    zero-demand station-hours.
    """

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    non_zero = y_true != 0

    if not np.any(non_zero):
        return np.nan

    return (
        np.mean(
            np.abs(
                (
                    y_true[non_zero]
                    - y_pred[non_zero]
                )
                / y_true[non_zero]
            )
        )
        * 100
    )


def calculate_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> dict:
    """
    Calculate regression metrics.
    """

    mae = mean_absolute_error(
        y_true,
        y_pred,
    )

    rmse = np.sqrt(
        mean_squared_error(
            y_true,
            y_pred,
        )
    )

    r2 = r2_score(
        y_true,
        y_pred,
    )

    mape = calculate_mape(
        y_true,
        y_pred,
    )

    return {
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
        "MAPE": mape,
    }


# ============================================================
# BASELINE MODELS
# ============================================================

def previous_hour_baseline(
    df: pd.DataFrame,
) -> np.ndarray:
    """
    Predict next-hour demand using the previous hour's demand.
    """

    return df["demand_lag_1h"].to_numpy()


def previous_day_baseline(
    df: pd.DataFrame,
) -> np.ndarray:
    """
    Predict next-hour demand using demand from 24 hours ago.
    """

    return df["demand_lag_24h"].to_numpy()


# ============================================================
# MACHINE LEARNING MODELS
# ============================================================

def create_models() -> dict:
    """
    Create candidate regression models.

    Random states are fixed for reproducibility.
    """

    models = {

        "Linear Regression": LinearRegression(),

        "Random Forest": RandomForestRegressor(
            n_estimators=300,
            random_state=42,
            n_jobs=-1,
            min_samples_leaf=2,
        ),

        "Gradient Boosting": GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.05,
            max_depth=3,
            random_state=42,
        ),

        "HistGradientBoosting": HistGradientBoostingRegressor(
            max_iter=200,
            learning_rate=0.05,
            max_leaf_nodes=31,
            random_state=42,
        ),
    }

    return models


# ============================================================
# EVALUATION HELPER
# ============================================================

def evaluate_predictions(
    model_name: str,
    split_name: str,
    y_true: np.ndarray,
    predictions: np.ndarray,
) -> dict:

    metrics = calculate_metrics(
        y_true,
        predictions,
    )

    return {
        "Model": model_name,
        "Split": split_name,
        "MAE": metrics["MAE"],
        "RMSE": metrics["RMSE"],
        "R2": metrics["R2"],
        "MAPE": metrics["MAPE"],
    }


# ============================================================
# MAIN TRAINING PIPELINE
# ============================================================

def main():

    print("=" * 60)
    print("EV CHARGING DEMAND MODEL TRAINING")
    print("=" * 60)

    # --------------------------------------------------------
    # Create output directories
    # --------------------------------------------------------

    MODEL_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    REPORT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    PREDICTION_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    # --------------------------------------------------------
    # Load datasets
    # --------------------------------------------------------

    print("\nLoading datasets...")

    train_df = load_split(
        TRAIN_PATH
    )

    validation_df = load_split(
        VALIDATION_PATH
    )

    test_df = load_split(
        TEST_PATH
    )

    print(
        f"Train      : {len(train_df):,} rows"
    )

    print(
        f"Validation : {len(validation_df):,} rows"
    )

    print(
        f"Test       : {len(test_df):,} rows"
    )

    # --------------------------------------------------------
    # Prepare X and y
    # --------------------------------------------------------

    X_train = train_df[
        FEATURE_COLUMNS
    ]

    y_train = train_df[
        TARGET_COLUMN
    ]

    X_validation = validation_df[
        FEATURE_COLUMNS
    ]

    y_validation = validation_df[
        TARGET_COLUMN
    ]

    X_test = test_df[
        FEATURE_COLUMNS
    ]

    y_test = test_df[
        TARGET_COLUMN
    ]

    # --------------------------------------------------------
    # Verify no missing values
    # --------------------------------------------------------

    print("\nFeature validation:")

    print(
        f"Train missing values      : "
        f"{X_train.isna().sum().sum()}"
    )

    print(
        f"Validation missing values : "
        f"{X_validation.isna().sum().sum()}"
    )

    print(
        f"Test missing values       : "
        f"{X_test.isna().sum().sum()}"
    )

    # ========================================================
    # BASELINES
    # ========================================================

    print("\n" + "=" * 60)
    print("BASELINE EVALUATION")
    print("=" * 60)

    validation_baseline_results = []

    # --------------------------------------------------------
    # Previous-hour baseline
    # --------------------------------------------------------

    previous_hour_validation = (
        previous_hour_baseline(
            validation_df
        )
    )

    result = evaluate_predictions(
        "Previous Hour",
        "Validation",
        y_validation.to_numpy(),
        previous_hour_validation,
    )

    validation_baseline_results.append(
        result
    )

    print("\nPrevious Hour Baseline")

    print(
        f"MAE  : {result['MAE']:.4f}"
    )

    print(
        f"RMSE : {result['RMSE']:.4f}"
    )

    print(
        f"R²   : {result['R2']:.4f}"
    )

    print(
        f"MAPE : {result['MAPE']:.2f}%"
    )

    # --------------------------------------------------------
    # Previous-day baseline
    # --------------------------------------------------------

    previous_day_validation = (
        previous_day_baseline(
            validation_df
        )
    )

    result = evaluate_predictions(
        "Previous Day",
        "Validation",
        y_validation.to_numpy(),
        previous_day_validation,
    )

    validation_baseline_results.append(
        result
    )

    print("\nPrevious Day Baseline")

    print(
        f"MAE  : {result['MAE']:.4f}"
    )

    print(
        f"RMSE : {result['RMSE']:.4f}"
    )

    print(
        f"R²   : {result['R2']:.4f}"
    )

    print(
        f"MAPE : {result['MAPE']:.2f}%"
    )

    # ========================================================
    # MACHINE LEARNING MODELS
    # ========================================================

    print("\n" + "=" * 60)
    print("MODEL TRAINING")
    print("=" * 60)

    models = create_models()

    validation_results = []

    trained_models = {}

    # --------------------------------------------------------
    # Train every candidate model on training data.
    # Evaluate only on validation data for model selection.
    # --------------------------------------------------------

    for model_name, model in models.items():

        print(
            f"\nTraining: {model_name}"
        )

        model.fit(
            X_train,
            y_train,
        )

        validation_predictions = (
            model.predict(
                X_validation
            )
        )

        result = evaluate_predictions(
            model_name,
            "Validation",
            y_validation.to_numpy(),
            validation_predictions,
        )

        validation_results.append(
            result
        )

        trained_models[
            model_name
        ] = model

        print(
            f"MAE  : {result['MAE']:.4f}"
        )

        print(
            f"RMSE : {result['RMSE']:.4f}"
        )

        print(
            f"R²   : {result['R2']:.4f}"
        )

        print(
            f"MAPE : {result['MAPE']:.2f}%"
        )

    # ========================================================
    # VALIDATION COMPARISON
    # ========================================================

    validation_results_df = pd.DataFrame(
        validation_results
        + validation_baseline_results
    )

    validation_results_df = (
        validation_results_df
        .sort_values("MAE")
        .reset_index(drop=True)
    )

    print("\n" + "=" * 60)
    print("VALIDATION RESULTS")
    print("=" * 60)

    print(
        validation_results_df.to_string(
            index=False
        )
    )

    # --------------------------------------------------------
    # Model selection
    #
    # MAE is the primary selection metric.
    # This is based ONLY on validation performance.
    # --------------------------------------------------------

    model_validation_df = (
        pd.DataFrame(
            validation_results
        )
        .sort_values("MAE")
        .reset_index(drop=True)
    )

    selected_model_name = (
        model_validation_df.iloc[0]["Model"]
    )

    selected_model = trained_models[
        selected_model_name
    ]

    print("\n" + "=" * 60)
    print("SELECTED MODEL")
    print("=" * 60)

    print(
        f"Model: {selected_model_name}"
    )

    print(
        "Selection criterion: "
        "lowest validation MAE"
    )

    # ========================================================
    # FINAL TEST EVALUATION
    # ========================================================

    print("\n" + "=" * 60)
    print("FINAL TEST EVALUATION")
    print("=" * 60)

    # --------------------------------------------------------
    # Selected ML model
    # --------------------------------------------------------

    test_predictions = selected_model.predict(
        X_test
    )

    test_result = evaluate_predictions(
        selected_model_name,
        "Test",
        y_test.to_numpy(),
        test_predictions,
    )

    # --------------------------------------------------------
    # Test baselines
    # --------------------------------------------------------

    test_previous_hour = (
        previous_hour_baseline(
            test_df
        )
    )

    test_previous_day = (
        previous_day_baseline(
            test_df
        )
    )

    previous_hour_test_result = (
        evaluate_predictions(
            "Previous Hour",
            "Test",
            y_test.to_numpy(),
            test_previous_hour,
        )
    )

    previous_day_test_result = (
        evaluate_predictions(
            "Previous Day",
            "Test",
            y_test.to_numpy(),
            test_previous_day,
        )
    )

    test_results = pd.DataFrame(
        [
            previous_hour_test_result,
            previous_day_test_result,
            test_result,
        ]
    )

    print(
        test_results.to_string(
            index=False
        )
    )

    # ========================================================
    # SAVE TEST PREDICTIONS
    # ========================================================

    predictions_df = test_df[
        [
            "station_id",
            "hour",
            TARGET_COLUMN,
        ]
    ].copy()

    predictions_df[
        "prediction"
    ] = test_predictions

    predictions_df[
        "absolute_error"
    ] = np.abs(
        predictions_df[
            TARGET_COLUMN
        ]
        - predictions_df[
            "prediction"
        ]
    )

    predictions_path = (
        PREDICTION_DIR
        / "test_predictions.csv"
    )

    predictions_df.to_csv(
        predictions_path,
        index=False,
    )

    # ========================================================
    # SAVE MODEL
    # ========================================================

    model_path = (
        MODEL_DIR
        / "selected_model.joblib"
    )

    joblib.dump(
        selected_model,
        model_path,
    )

    # --------------------------------------------------------
    # Save model metadata
    # --------------------------------------------------------

    metadata = {
        "selected_model": selected_model_name,
        "selection_metric": "Validation MAE",
        "target": TARGET_COLUMN,
        "feature_columns": FEATURE_COLUMNS,
        "train_rows": len(train_df),
        "validation_rows": len(validation_df),
        "test_rows": len(test_df),
    }

    metadata_path = (
        MODEL_DIR
        / "model_metadata.joblib"
    )

    joblib.dump(
        metadata,
        metadata_path,
    )

    # ========================================================
    # SAVE RESULTS
    # ========================================================

    validation_path = (
        REPORT_DIR
        / "validation_results.csv"
    )

    validation_results_df.to_csv(
        validation_path,
        index=False,
    )

    test_results_path = (
        REPORT_DIR
        / "test_results.csv"
    )

    test_results.to_csv(
        test_results_path,
        index=False,
    )

    # ========================================================
    # FEATURE IMPORTANCE
    # ========================================================

    if hasattr(
        selected_model,
        "feature_importances_",
    ):

        importance_df = pd.DataFrame(
            {
                "feature": FEATURE_COLUMNS,
                "importance": (
                    selected_model
                    .feature_importances_
                ),
            }
        )

        importance_df = (
            importance_df
            .sort_values(
                "importance",
                ascending=False,
            )
            .reset_index(drop=True)
        )

        importance_path = (
            REPORT_DIR
            / "feature_importance.csv"
        )

        importance_df.to_csv(
            importance_path,
            index=False,
        )

        print(
            "\nFeature importance:"
        )

        print(
            importance_df.to_string(
                index=False
            )
        )

    # ========================================================
    # FINAL OUTPUT
    # ========================================================

    print("\n" + "=" * 60)
    print("TRAINING COMPLETE")
    print("=" * 60)

    print(
        f"\nSelected model:"
        f" {selected_model_name}"
    )

    print(
        f"Model saved:"
        f"\n{model_path}"
    )

    print(
        f"\nPredictions saved:"
        f"\n{predictions_path}"
    )

    print(
        f"\nValidation results:"
        f"\n{validation_path}"
    )

    print(
        f"\nTest results:"
        f"\n{test_results_path}"
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()