from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "EV_Charging_Demand_Dataset_Full.csv"


def load_data() -> pd.DataFrame:
    """Load and prepare the raw dataset."""
    df = pd.read_csv(DATA_PATH)

    datetime_columns = [
        "timestamp",
        "arrival_time",
        "charging_start_time",
        "charging_end_time",
    ]

    for column in datetime_columns:
        df[column] = pd.to_datetime(df[column], errors="coerce")

    df = df.sort_values(
        ["timestamp", "station_id"]
    ).reset_index(drop=True)

    return df


def investigate_target(df: pd.DataFrame) -> None:
    """Investigate charging_demand and station_load."""

    print("\n" + "=" * 60)
    print("TARGET INVESTIGATION")
    print("=" * 60)

    print("\nCharging demand statistics:")
    print(df["charging_demand"].describe())

    print("\nStation load statistics:")
    print(df["station_load"].describe())

    correlation = df[
        ["charging_demand", "station_load"]
    ].corr().iloc[0, 1]

    print(
        f"\nCorrelation between charging_demand "
        f"and station_load: {correlation:.6f}"
    )

    print("\nCharging demand missing values:")
    print(df["charging_demand"].isna().sum())

    print("\nStation load missing values:")
    print(df["station_load"].isna().sum())


def investigate_categories(df: pd.DataFrame) -> None:
    """Display important categorical distributions."""

    print("\n" + "=" * 60)
    print("CATEGORY INVESTIGATION")
    print("=" * 60)

    categorical_columns = [
        "station_id",
        "location_type",
        "vehicle_type",
        "traffic_density",
        "weather_condition",
        "day_of_week",
        "time_slot",
        "charging_priority",
    ]

    for column in categorical_columns:
        print(f"\n--- {column} ---")
        print(df[column].value_counts())


def investigate_time(df: pd.DataFrame) -> None:
    """Investigate temporal coverage."""

    print("\n" + "=" * 60)
    print("TIME INVESTIGATION")
    print("=" * 60)

    print(
        f"\nUnique timestamps: "
        f"{df['timestamp'].nunique()}"
    )

    print(
        f"Unique stations: "
        f"{df['station_id'].nunique()}"
    )

    print(
        f"Dataset start: "
        f"{df['timestamp'].min()}"
    )

    print(
        f"Dataset end: "
        f"{df['timestamp'].max()}"
    )

    print("\nRows per station:")

    print(
        df.groupby("station_id")
        .size()
        .sort_values()
    )


if __name__ == "__main__":

    print("=" * 60)
    print("EV CHARGING DEMAND — EDA")
    print("=" * 60)

    df = load_data()

    print(
        f"\nLoaded dataset: "
        f"{df.shape[0]} rows × {df.shape[1]} columns"
    )

    investigate_target(df)

    investigate_categories(df)

    investigate_time(df)

    print("\n" + "=" * 60)
    print("EDA INVESTIGATION COMPLETE")
    print("=" * 60)