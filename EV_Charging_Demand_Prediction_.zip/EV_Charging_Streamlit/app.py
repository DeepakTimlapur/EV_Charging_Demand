from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st


# ============================================================
# PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="EV Charging Demand Prediction",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DATA_PATH = (
    BASE_DIR
    / "data"
    / "EV_Charging_Demand_Dataset_Full.csv"
)

MODEL_PATH = (
    BASE_DIR
    / "models"
    / "selected_model.joblib"
)

METADATA_PATH = (
    BASE_DIR
    / "models"
    / "model_metadata.joblib"
)

TRAIN_PATH = (
    BASE_DIR
    / "outputs"
    / "train_data.csv"
)

VALIDATION_PATH = (
    BASE_DIR
    / "outputs"
    / "validation_data.csv"
)

TEST_PATH = (
    BASE_DIR
    / "outputs"
    / "test_data.csv"
)

TEST_PREDICTIONS_PATH = (
    BASE_DIR
    / "outputs"
    / "predictions"
    / "test_predictions.csv"
)

VALIDATION_RESULTS_PATH = (
    BASE_DIR
    / "outputs"
    / "reports"
    / "validation_results.csv"
)

TEST_RESULTS_PATH = (
    BASE_DIR
    / "outputs"
    / "reports"
    / "test_results.csv"
)

FEATURE_IMPORTANCE_PATH = (
    BASE_DIR
    / "outputs"
    / "reports"
    / "feature_importance.csv"
)

STATION_ERROR_PATH = (
    BASE_DIR
    / "outputs"
    / "reports"
    / "station_error_analysis.csv"
)


# ============================================================
# CUSTOM CSS
# ============================================================

st.markdown(
    """
    <style>

    .main-title {
        font-size: 44px;
        font-weight: 750;
        margin-bottom: 4px;
    }

    .subtitle {
        font-size: 18px;
        color: #9ca3af;
        margin-bottom: 30px;
    }

    .section-title {
        font-size: 31px;
        font-weight: 700;
        margin-top: 5px;
        margin-bottom: 8px;
    }

    .section-description {
        color: #9ca3af;
        font-size: 16px;
        margin-bottom: 28px;
    }

    .small-note {
        color: #9ca3af;
        font-size: 14px;
    }

    </style>
    """,
    unsafe_allow_html=True,
)


# ============================================================
# LOAD MODEL
# ============================================================

@st.cache_resource
def load_model():

    return joblib.load(
        MODEL_PATH
    )


# ============================================================
# LOAD METADATA
# ============================================================

@st.cache_resource
def load_metadata():

    return joblib.load(
        METADATA_PATH
    )


# ============================================================
# LOAD RAW DATA
# ============================================================

@st.cache_data
def load_raw_data():

    df = pd.read_csv(
        DATA_PATH
    )

    datetime_columns = [
        "timestamp",
        "arrival_time",
        "charging_start_time",
        "charging_end_time",
    ]

    for column in datetime_columns:

        if column in df.columns:

            df[column] = pd.to_datetime(
                df[column],
                errors="coerce",
            )

    return df


# ============================================================
# LOAD CSV FILE
# ============================================================

@st.cache_data
def load_csv(path):

    return pd.read_csv(
        path
    )


# ============================================================
# LOAD ALL ARTIFACTS
# ============================================================

try:

    model = load_model()

    metadata = load_metadata()

    raw_data = load_raw_data()

    train_data = load_csv(
        TRAIN_PATH
    )

    validation_data = load_csv(
        VALIDATION_PATH
    )

    test_data = load_csv(
        TEST_PATH
    )

    test_predictions = load_csv(
        TEST_PREDICTIONS_PATH
    )

    validation_results = load_csv(
        VALIDATION_RESULTS_PATH
    )

    test_results = load_csv(
        TEST_RESULTS_PATH
    )

    feature_importance = load_csv(
        FEATURE_IMPORTANCE_PATH
    )

    station_errors = load_csv(
        STATION_ERROR_PATH
    )

except Exception as e:

    st.error(
        "The dashboard could not load the project artifacts."
    )

    st.exception(e)

    st.stop()


# ============================================================
# NORMALIZE REPORT COLUMN NAMES
# ============================================================

def clean_columns(df):

    df.columns = (
        df.columns
        .astype(str)
        .str.strip()
    )

    return df


validation_results = clean_columns(
    validation_results
)

test_results = clean_columns(
    test_results
)

feature_importance = clean_columns(
    feature_importance
)

station_errors = clean_columns(
    station_errors
)


# ============================================================
# MODEL COLUMN COMPATIBILITY
# ============================================================

if (
    "Model" in validation_results.columns
    and "model" not in validation_results.columns
):

    validation_results = validation_results.rename(
        columns={
            "Model": "model"
        }
    )


if (
    "Model" in test_results.columns
    and "model" not in test_results.columns
):

    test_results = test_results.rename(
        columns={
            "Model": "model"
        }
    )


# ============================================================
# METRIC COLUMN COMPATIBILITY
# ============================================================

def normalize_metrics(df):

    rename_map = {}

    possible_columns = {
        "mae": "MAE",
        "Mae": "MAE",
        "rmse": "RMSE",
        "Rmse": "RMSE",
        "r2": "R2",
        "R²": "R2",
        "mape": "MAPE",
        "Mape": "MAPE",
    }

    for old_name, new_name in possible_columns.items():

        if (
            old_name in df.columns
            and new_name not in df.columns
        ):

            rename_map[old_name] = new_name

    if rename_map:

        df = df.rename(
            columns=rename_map
        )

    return df


validation_results = normalize_metrics(
    validation_results
)

test_results = normalize_metrics(
    test_results
)


# ============================================================
# DATETIME CONVERSION
# ============================================================

for df in [
    train_data,
    validation_data,
    test_data,
    test_predictions,
]:

    if "timestamp" in df.columns:

        df["timestamp"] = pd.to_datetime(
            df["timestamp"],
            errors="coerce",
        )


# ============================================================
# COMBINE MODEL DATA
# ============================================================

all_model_data = pd.concat(
    [
        train_data,
        validation_data,
        test_data,
    ],
    ignore_index=True,
)


if "timestamp" in all_model_data.columns:

    all_model_data["timestamp"] = pd.to_datetime(
        all_model_data["timestamp"],
        errors="coerce",
    )


# ============================================================
# MODEL FEATURES
# ============================================================

DEFAULT_FEATURE_COLUMNS = [

    "hour_of_day",

    "day_of_week",

    "day_of_month",

    "month",

    "is_weekend",

    "demand_lag_1h",

    "demand_lag_2h",

    "demand_lag_3h",

    "demand_lag_24h",

    "station_load_lag_1h",

    "station_load_lag_24h",

    "queue_lag_1h",

    "queue_lag_24h",

    "demand_rolling_mean_3h",

    "demand_rolling_mean_6h",

    "demand_rolling_mean_24h",
]


FEATURE_COLUMNS = metadata.get(
    "feature_columns",
    DEFAULT_FEATURE_COLUMNS,
)


TARGET_COLUMN = metadata.get(
    "target_column",
    "next_hour_demand",
)


# ============================================================
# FINAL MODEL RESULT
# ============================================================

if "model" in test_results.columns:

    final_row = test_results[
        test_results["model"]
        .astype(str)
        .str.contains(
            "Gradient Boosting",
            case=False,
            na=False,
        )
    ]

else:

    final_row = pd.DataFrame()


# ============================================================
# SELECTED MODEL NAME
# ============================================================

SELECTED_MODEL_NAME = metadata.get(
    "model_name",
    "Gradient Boosting",
)


# ============================================================
# HELPER — SECTION HEADER
# ============================================================

def section_header(
    title,
    description,
):

    st.markdown(
        f"""
        <div class="section-title">
            {title}
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        f"""
        <div class="section-description">
            {description}
        </div>
        """,
        unsafe_allow_html=True,
    )


# ============================================================
# HELPER — METRIC ROW
# ============================================================

def metric_row(metrics):

    columns = st.columns(
        len(metrics)
    )

    for column, (
        label,
        value,
        help_text,
    ) in zip(
        columns,
        metrics,
    ):

        with column:

            st.metric(
                label=label,
                value=value,
                help=help_text,
            )


# ============================================================
# SIDEBAR NAVIGATION
# ============================================================

with st.sidebar:

    st.markdown(
        """
        # ⚡ EV Charging
        ## Demand Prediction
        """
    )

    st.markdown("---")

    st.markdown(
        "### 📌 Navigation"
    )

    section = st.radio(
        "Select Section",
        [
            "🏠 Project Overview",
            "📊 Data Overview",
            "🔎 Exploratory Data Analysis",
            "⚙️ Feature Engineering",
            "✂️ Train / Validation / Test",
            "🤖 Model Training",
            "📈 Model Performance",
            "🔮 Forecast",
            "🏢 Station Analysis",
            "⭐ Feature Importance",
            "📚 Methodology",
        ],
    )

    st.markdown("---")

    st.caption(
        "EV Charging Demand Prediction"
    )

    st.caption(
        "Station-level next-hour forecasting"
    )


# ============================================================
# 1. PROJECT OVERVIEW
# ============================================================

if section == "🏠 Project Overview":

    st.markdown(
        """
        <div class="main-title">
            ⚡ EV Charging Demand Prediction
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        """
        <div class="subtitle">
            Machine Learning system for next-hour
            station-level EV charging demand forecasting
        </div>
        """,
        unsafe_allow_html=True,
    )

    section_header(
        "Project Overview",
        "A complete chronological machine-learning "
        "pipeline for predicting future EV charging demand.",
    )

    # --------------------------------------------------------
    # TOP METRICS
    # --------------------------------------------------------

    metric_row(
        [
            (
                "Raw Observations",
                f"{len(raw_data):,}",
                "Original event-level records.",
            ),

            (
                "Stations",
                f"{raw_data['station_id'].nunique():,}",
                "Unique charging stations.",
            ),

            (
                "Usable Station-Hour Records",
                f"{len(all_model_data):,}",
                "Records available after feature and target preparation.",
            ),

            (
                "Model Features",
                f"{len(FEATURE_COLUMNS):,}",
                "Features used by the final model.",
            ),
        ]
    )

    # --------------------------------------------------------
    # PREDICTION OBJECTIVE
    # --------------------------------------------------------

    st.markdown(
        "### 🎯 Prediction Objective"
    )

    st.info(
        "Predict the next hour's station-level "
        "charging demand using only historical "
        "information available before that future hour."
    )

    # --------------------------------------------------------
    # QUICK DATA BREAKDOWN
    # --------------------------------------------------------

    st.markdown(
        "### 📊 Dataset Breakdown"
    )

    overview_tab1, overview_tab2, overview_tab3 = st.tabs(
        [
            "🏢 Stations",
            "📍 Locations",
            "🚗 Vehicle Types",
        ]
    )

    # --------------------------------------------------------
    # STATION BREAKDOWN
    # --------------------------------------------------------

    with overview_tab1:

        station_overview = (
            raw_data
            .groupby("station_id")
            .agg(
                records=(
                    "station_id",
                    "count",
                ),

                average_demand=(
                    "charging_demand",
                    "mean",
                ),

                total_energy=(
                    "energy_consumed_kWh",
                    "sum",
                ),
            )
            .reset_index()
            .sort_values(
                "average_demand",
                ascending=False,
            )
        )

        st.markdown(
            "#### Station-wise Average Demand"
        )

        fig = px.bar(
            station_overview,
            x="station_id",
            y="average_demand",
            title="Average Charging Demand by Station",
        )

        fig.update_layout(
            xaxis_title="Station",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.dataframe(
            station_overview,
            use_container_width=True,
            hide_index=True,
        )

    # --------------------------------------------------------
    # LOCATION BREAKDOWN
    # --------------------------------------------------------

    with overview_tab2:

        location_overview = (
            raw_data
            .groupby("location_type")
            .agg(
                records=(
                    "location_type",
                    "count",
                ),

                stations=(
                    "station_id",
                    "nunique",
                ),

                vehicles=(
                    "vehicle_id",
                    "nunique",
                ),

                average_demand=(
                    "charging_demand",
                    "mean",
                ),

                total_energy=(
                    "energy_consumed_kWh",
                    "sum",
                ),
            )
            .reset_index()
        )

        st.markdown(
            "#### Location-wise Average Demand"
        )

        fig = px.bar(
            location_overview,
            x="location_type",
            y="average_demand",
            text="average_demand",
            title="Average Charging Demand by Location",
        )

        fig.update_traces(
            texttemplate="%{text:.2f}",
            textposition="outside",
        )

        fig.update_layout(
            xaxis_title="Location Type",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.dataframe(
            location_overview,
            use_container_width=True,
            hide_index=True,
        )

    # --------------------------------------------------------
    # VEHICLE BREAKDOWN
    # --------------------------------------------------------

    with overview_tab3:

        vehicle_overview = (
            raw_data
            .groupby("vehicle_type")
            .agg(
                records=(
                    "vehicle_type",
                    "count",
                ),

                vehicles=(
                    "vehicle_id",
                    "nunique",
                ),

                average_demand=(
                    "charging_demand",
                    "mean",
                ),

                average_battery=(
                    "battery_capacity_kWh",
                    "mean",
                ),

                total_energy=(
                    "energy_consumed_kWh",
                    "sum",
                ),
            )
            .reset_index()
        )

        st.markdown(
            "#### Vehicle Type-wise Average Demand"
        )

        fig = px.bar(
            vehicle_overview,
            x="vehicle_type",
            y="average_demand",
            text="average_demand",
            title="Average Charging Demand by Vehicle Type",
        )

        fig.update_traces(
            texttemplate="%{text:.2f}",
            textposition="outside",
        )

        fig.update_layout(
            xaxis_title="Vehicle Type",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.dataframe(
            vehicle_overview,
            use_container_width=True,
            hide_index=True,
        )

    # --------------------------------------------------------
    # PROJECT WORKFLOW
    # --------------------------------------------------------

    st.markdown(
        "### 🔄 Project Workflow"
    )

    workflow = pd.DataFrame(
        {
            "Stage": [

                "Raw Data",

                "Hourly Aggregation",

                "Feature Engineering",

                "Chronological Split",

                "Model Training",

                "Validation",

                "Final Test",

                "Forecast",
            ],

            "Description": [

                "8,354 EV charging observations",

                "Complete station × hour panel",

                "Historical lags and rolling statistics",

                "70% / 15% / 15% chronological split",

                "4 regression models + 2 forecasting baselines",

                "Model selection using validation MAE",

                "Held-out test evaluation",

                "Next-hour station-level prediction",
            ],
        }
    )

    st.dataframe(
        workflow,
        use_container_width=True,
        hide_index=True,
    )

    # --------------------------------------------------------
    # FINAL MODEL
    # --------------------------------------------------------

    st.markdown(
        "### 🤖 Selected Model"
    )

    st.success(
        f"Selected model: **{SELECTED_MODEL_NAME}**"
    )

    # --------------------------------------------------------
    # FINAL TEST
    # --------------------------------------------------------

    st.markdown(
        "### 📊 Final Test Performance"
    )

    if len(final_row) > 0:

        row = final_row.iloc[0]

        metric_row(
            [
                (
                    "Test MAE",
                    f"{row['MAE']:.2f}",
                    None,
                ),

                (
                    "Test RMSE",
                    f"{row['RMSE']:.2f}",
                    None,
                ),

                (
                    "Test R²",
                    f"{row['R2']:.4f}",
                    None,
                ),

                (
                    "Test MAPE",
                    f"{row['MAPE']:.2f}%",
                    None,
                ),
            ]
        )

    st.caption(
        "MAPE is supplementary because the dataset "
        "contains zero-demand station-hours."
    )


# ============================================================
# 2. DATA OVERVIEW
# ============================================================

elif section == "📊 Data Overview":

    section_header(
        "📊 Data Overview",
        "Detailed summary of the original EV charging dataset.",
    )

    metric_row(
        [
            (
                "Rows",
                f"{len(raw_data):,}",
                None,
            ),

            (
                "Columns",
                f"{raw_data.shape[1]:,}",
                None,
            ),

            (
                "Stations",
                f"{raw_data['station_id'].nunique():,}",
                None,
            ),

            (
                "Vehicles",
                f"{raw_data['vehicle_id'].nunique():,}",
                None,
            ),
        ]
    )

    st.markdown(
        "### 🕐 Dataset Time Range"
    )

    col1, col2 = st.columns(2)

    with col1:

        st.metric(
            "Start",
            str(
                raw_data["timestamp"].min()
            ),
        )

    with col2:

        st.metric(
            "End",
            str(
                raw_data["timestamp"].max()
            ),
        )

    st.markdown(
        "### ✅ Data Quality"
    )

    quality = pd.DataFrame(
        {
            "Check": [

                "Missing values",

                "Duplicate rows",

                "Invalid timestamps",

                "Unique stations",

                "Unique vehicles",
            ],

            "Result": [

                int(
                    raw_data
                    .isna()
                    .sum()
                    .sum()
                ),

                int(
                    raw_data
                    .duplicated()
                    .sum()
                ),

                int(
                    raw_data["timestamp"]
                    .isna()
                    .sum()
                ),

                int(
                    raw_data["station_id"]
                    .nunique()
                ),

                int(
                    raw_data["vehicle_id"]
                    .nunique()
                ),
            ],
        }
    )

    st.dataframe(
        quality,
        use_container_width=True,
        hide_index=True,
    )

    st.markdown(
        "### 📋 Dataset Preview"
    )

    st.dataframe(
        raw_data.head(20),
        use_container_width=True,
        hide_index=True,
    )

    st.markdown(
        "### 🎯 Charging Demand Statistics"
    )

    target_stats = (
        raw_data["charging_demand"]
        .describe()
        .to_frame(
            name="charging_demand"
        )
    )

    st.dataframe(
        target_stats,
        use_container_width=True,
    )

    st.markdown(
        "### 📑 Dataset Columns"
    )

    columns_table = pd.DataFrame(
        {
            "Column": raw_data.columns,
            "Data Type": [
                str(dtype)
                for dtype in raw_data.dtypes
            ],
        }
    )

    st.dataframe(
        columns_table,
        use_container_width=True,
        hide_index=True,
    )


# ============================================================
# 3. EXPLORATORY DATA ANALYSIS
# ============================================================

elif section == "🔎 Exploratory Data Analysis":

    section_header(
        "🔎 Exploratory Data Analysis",
        "Analyze charging demand station-wise, "
        "location-wise, vehicle-wise and across time.",
    )

    tab_station, tab_location, tab_vehicle, tab_time, tab_corr = st.tabs(
        [
            "🏢 Station-wise",
            "📍 Location-wise",
            "🚗 Vehicle Type",
            "⏰ Time Analysis",
            "📊 Correlation",
        ]
    )

    # ========================================================
    # STATION-WISE
    # ========================================================

    with tab_station:

        st.markdown(
            "### 🏢 Station-wise Charging Analysis"
        )

        st.write(
            "Compare charging activity and demand "
            "across all 20 charging stations."
        )

        station_summary = (
            raw_data
            .groupby("station_id")
            .agg(
                observations=(
                    "station_id",
                    "count",
                ),

                unique_vehicles=(
                    "vehicle_id",
                    "nunique",
                ),

                average_demand=(
                    "charging_demand",
                    "mean",
                ),

                maximum_demand=(
                    "charging_demand",
                    "max",
                ),

                average_power=(
                    "charging_power_kW",
                    "mean",
                ),

                total_energy=(
                    "energy_consumed_kWh",
                    "sum",
                ),
            )
            .reset_index()
            .sort_values(
                "average_demand",
                ascending=False,
            )
        )

        metric_row(
            [
                (
                    "Stations",
                    f"{len(station_summary)}",
                    None,
                ),

                (
                    "Average Demand",
                    f"{raw_data['charging_demand'].mean():.2f}",
                    None,
                ),

                (
                    "Maximum Demand",
                    f"{raw_data['charging_demand'].max():.2f}",
                    None,
                ),

                (
                    "Total Energy",
                    f"{raw_data['energy_consumed_kWh'].sum():,.2f} kWh",
                    None,
                ),
            ]
        )

        st.markdown(
            "#### Average Charging Demand by Station"
        )

        fig = px.bar(
            station_summary,
            x="station_id",
            y="average_demand",
            text="average_demand",
            title="Average Charging Demand — Station-wise",
        )

        fig.update_traces(
            texttemplate="%{text:.2f}",
            textposition="outside",
        )

        fig.update_layout(
            xaxis_title="Station",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.markdown(
            "#### Complete Station-wise Summary"
        )

        display_station = station_summary.copy()

        display_station.columns = [

            "Station",

            "Observations",

            "Unique Vehicles",

            "Average Demand",

            "Maximum Demand",

            "Average Charging Power (kW)",

            "Total Energy (kWh)",
        ]

        st.dataframe(
            display_station.style.format(
                {
                    "Average Demand": "{:.2f}",
                    "Maximum Demand": "{:.2f}",
                    "Average Charging Power (kW)": "{:.2f}",
                    "Total Energy (kWh)": "{:.2f}",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

        st.markdown(
            "#### 🔍 Individual Station"
        )

        selected_station = st.selectbox(
            "Select a station",

            sorted(
                raw_data["station_id"]
                .dropna()
                .unique()
            ),

            key="eda_station",
        )

        selected_station_data = raw_data[
            raw_data["station_id"]
            == selected_station
        ]

        metric_row(
            [
                (
                    "Records",
                    f"{len(selected_station_data):,}",
                    None,
                ),

                (
                    "Vehicles",
                    f"{selected_station_data['vehicle_id'].nunique():,}",
                    None,
                ),

                (
                    "Average Demand",
                    f"{selected_station_data['charging_demand'].mean():.2f}",
                    None,
                ),

                (
                    "Total Energy",
                    f"{selected_station_data['energy_consumed_kWh'].sum():.2f} kWh",
                    None,
                ),
            ]
        )

    # ========================================================
    # LOCATION-WISE
    # ========================================================

    with tab_location:

        st.markdown(
            "### 📍 Location-wise Charging Analysis"
        )

        st.write(
            "Compare EV charging demand between "
            "different station location types."
        )

        location_summary = (
            raw_data
            .groupby("location_type")
            .agg(
                observations=(
                    "location_type",
                    "count",
                ),

                stations=(
                    "station_id",
                    "nunique",
                ),

                vehicles=(
                    "vehicle_id",
                    "nunique",
                ),

                average_demand=(
                    "charging_demand",
                    "mean",
                ),

                maximum_demand=(
                    "charging_demand",
                    "max",
                ),

                average_power=(
                    "charging_power_kW",
                    "mean",
                ),

                total_energy=(
                    "energy_consumed_kWh",
                    "sum",
                ),
            )
            .reset_index()
            .sort_values(
                "average_demand",
                ascending=False,
            )
        )

        metric_row(
            [
                (
                    "Location Types",
                    f"{len(location_summary)}",
                    None,
                ),

                (
                    "Stations",
                    f"{raw_data['station_id'].nunique()}",
                    None,
                ),

                (
                    "Average Demand",
                    f"{raw_data['charging_demand'].mean():.2f}",
                    None,
                ),

                (
                    "Total Energy",
                    f"{raw_data['energy_consumed_kWh'].sum():,.2f} kWh",
                    None,
                ),
            ]
        )

        st.markdown(
            "#### Average Charging Demand by Location"
        )

        fig = px.bar(
            location_summary,
            x="location_type",
            y="average_demand",
            text="average_demand",
            title="Average Charging Demand — Location-wise",
        )

        fig.update_traces(
            texttemplate="%{text:.2f}",
            textposition="outside",
        )

        fig.update_layout(
            xaxis_title="Location Type",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.markdown(
            "#### Complete Location-wise Summary"
        )

        display_location = location_summary.copy()

        display_location.columns = [

            "Location Type",

            "Observations",

            "Stations",

            "Vehicles",

            "Average Demand",

            "Maximum Demand",

            "Average Charging Power (kW)",

            "Total Energy (kWh)",
        ]

        st.dataframe(
            display_location.style.format(
                {
                    "Average Demand": "{:.2f}",
                    "Maximum Demand": "{:.2f}",
                    "Average Charging Power (kW)": "{:.2f}",
                    "Total Energy (kWh)": "{:.2f}",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

        st.markdown(
            "#### Demand Distribution by Location"
        )

        fig = px.box(
            raw_data,
            x="location_type",
            y="charging_demand",
            title="Charging Demand Distribution by Location",
            points=False,
        )

        fig.update_layout(
            xaxis_title="Location Type",
            yaxis_title="Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

    # ========================================================
    # VEHICLE TYPE
    # ========================================================

    with tab_vehicle:

        st.markdown(
            "### 🚗 Vehicle Type-wise Charging Analysis"
        )

        st.write(
            "Compare charging behavior across "
            "different types of electric vehicles."
        )

        vehicle_summary = (
            raw_data
            .groupby("vehicle_type")
            .agg(
                observations=(
                    "vehicle_type",
                    "count",
                ),

                unique_vehicles=(
                    "vehicle_id",
                    "nunique",
                ),

                stations=(
                    "station_id",
                    "nunique",
                ),

                average_demand=(
                    "charging_demand",
                    "mean",
                ),

                maximum_demand=(
                    "charging_demand",
                    "max",
                ),

                average_battery=(
                    "battery_capacity_kWh",
                    "mean",
                ),

                average_power=(
                    "charging_power_kW",
                    "mean",
                ),

                average_energy=(
                    "energy_consumed_kWh",
                    "mean",
                ),

                total_energy=(
                    "energy_consumed_kWh",
                    "sum",
                ),
            )
            .reset_index()
            .sort_values(
                "average_demand",
                ascending=False,
            )
        )

        metric_row(
            [
                (
                    "Vehicle Types",
                    f"{len(vehicle_summary)}",
                    None,
                ),

                (
                    "Vehicles",
                    f"{raw_data['vehicle_id'].nunique():,}",
                    None,
                ),

                (
                    "Average Demand",
                    f"{raw_data['charging_demand'].mean():.2f}",
                    None,
                ),

                (
                    "Average Battery",
                    f"{raw_data['battery_capacity_kWh'].mean():.2f} kWh",
                    None,
                ),
            ]
        )

        st.markdown(
            "#### Average Charging Demand by Vehicle Type"
        )

        fig = px.bar(
            vehicle_summary,
            x="vehicle_type",
            y="average_demand",
            text="average_demand",
            title="Average Charging Demand — Vehicle Type",
        )

        fig.update_traces(
            texttemplate="%{text:.2f}",
            textposition="outside",
        )

        fig.update_layout(
            xaxis_title="Vehicle Type",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.markdown(
            "#### Complete Vehicle Type-wise Summary"
        )

        display_vehicle = vehicle_summary.copy()

        display_vehicle.columns = [

            "Vehicle Type",

            "Observations",

            "Unique Vehicles",

            "Stations",

            "Average Demand",

            "Maximum Demand",

            "Average Battery (kWh)",

            "Average Charging Power (kW)",

            "Average Energy (kWh)",

            "Total Energy (kWh)",
        ]

        st.dataframe(
            display_vehicle.style.format(
                {
                    "Average Demand": "{:.2f}",
                    "Maximum Demand": "{:.2f}",
                    "Average Battery (kWh)": "{:.2f}",
                    "Average Charging Power (kW)": "{:.2f}",
                    "Average Energy (kWh)": "{:.2f}",
                    "Total Energy (kWh)": "{:.2f}",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

        st.markdown(
            "#### Charging Demand Distribution by Vehicle Type"
        )

        fig = px.box(
            raw_data,
            x="vehicle_type",
            y="charging_demand",
            title="Charging Demand Distribution by Vehicle Type",
            points=False,
        )

        fig.update_layout(
            xaxis_title="Vehicle Type",
            yaxis_title="Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

    # ========================================================
    # TIME ANALYSIS
    # ========================================================

    with tab_time:

        st.markdown(
            "### ⏰ Time-based Demand Analysis"
        )

        hourly = (
            raw_data
            .assign(
                hour=raw_data[
                    "timestamp"
                ].dt.hour
            )
            .groupby(
                "hour",
                as_index=False,
            )["charging_demand"]
            .mean()
        )

        fig = px.line(
            hourly,
            x="hour",
            y="charging_demand",
            markers=True,
            title="Average Charging Demand by Hour",
        )

        fig.update_layout(
            xaxis_title="Hour of Day",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        day_summary = (
            raw_data
            .groupby(
                "day_of_week",
                as_index=False,
            )["charging_demand"]
            .mean()
        )

        fig = px.bar(
            day_summary,
            x="day_of_week",
            y="charging_demand",
            title="Average Charging Demand by Day of Week",
        )

        fig.update_layout(
            xaxis_title="Day of Week",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        time_slot_summary = (
            raw_data
            .groupby(
                "time_slot",
                as_index=False,
            )["charging_demand"]
            .mean()
        )

        fig = px.bar(
            time_slot_summary,
            x="time_slot",
            y="charging_demand",
            title="Average Charging Demand by Time Slot",
        )

        fig.update_layout(
            xaxis_title="Time Slot",
            yaxis_title="Average Charging Demand",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

    # ========================================================
    # CORRELATION
    # ========================================================

    with tab_corr:

        st.markdown(
            "### 📊 Numerical Feature Correlation"
        )

        numeric_columns = (
            raw_data
            .select_dtypes(
                include=np.number
            )
            .columns
        )

        correlation = (
            raw_data[
                numeric_columns
            ]
            .corr()
        )

        fig = px.imshow(
            correlation,
            text_auto=".2f",
            aspect="auto",
            title="Numerical Feature Correlation",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.warning(
            "Contemporaneous station_load is highly "
            "correlated with charging_demand and is "
            "therefore not used directly as a prediction feature."
        )


# ============================================================
# 4. FEATURE ENGINEERING
# ============================================================

elif section == "⚙️ Feature Engineering":

    section_header(
        "⚙️ Feature Engineering",
        "Historical features are constructed so that "
        "the model does not use future information.",
    )

    st.markdown(
        "### 🕐 Hourly Station Aggregation"
    )

    st.info(
        "The event-level dataset is transformed into "
        "a complete station × hour panel."
    )

    metric_row(
        [
            (
                "Station-Hour Rows",
                f"{len(all_model_data):,}",
                None,
            ),

            (
                "Stations",
                "20",
                None,
            ),

            (
                "Model Features",
                f"{len(FEATURE_COLUMNS)}",
                None,
            ),
        ]
    )

    st.markdown(
        "### 📌 Features Used by Final Model"
    )

    feature_types = []

    for feature in FEATURE_COLUMNS:

        if feature.startswith(
            "demand_lag"
        ):

            feature_type = "Demand Lag"

        elif feature.startswith(
            "station_load_lag"
        ):

            feature_type = "Station Load Lag"

        elif feature.startswith(
            "queue_lag"
        ):

            feature_type = "Queue Lag"

        elif feature.startswith(
            "demand_rolling"
        ):

            feature_type = "Rolling"

        else:

            feature_type = "Calendar"

        feature_types.append(
            feature_type
        )

    feature_table = pd.DataFrame(
        {
            "Feature": FEATURE_COLUMNS,
            "Type": feature_types,
        }
    )

    st.dataframe(
        feature_table,
        use_container_width=True,
        hide_index=True,
    )

    st.markdown(
        "### 🚫 Leakage Prevention"
    )

    st.warning(
        """
        Contemporaneous demand-related variables are excluded.

        Historical lagged values are allowed, while current-period
        variables such as charging_demand, station_load, queue_length,
        energy_consumed_kWh and waiting_time are not directly used
        as prediction inputs.
        """
    )

    st.markdown(
        "### 🎯 Target Definition"
    )

    st.code(
        "next_hour_demand = "
        "station-level charging_demand shifted by -1 hour"
    )

    st.markdown(
        "### 🔄 Rolling Features"
    )

    rolling_info = pd.DataFrame(
        {
            "Feature": [

                "demand_rolling_mean_3h",

                "demand_rolling_mean_6h",

                "demand_rolling_mean_24h",
            ],

            "Historical Window": [

                "Previous 3 hours",

                "Previous 6 hours",

                "Previous 24 hours",
            ],
        }
    )

    st.dataframe(
        rolling_info,
        use_container_width=True,
        hide_index=True,
    )

    st.caption(
        "Rolling statistics are calculated from shifted "
        "historical demand to avoid current-period leakage."
    )


# ============================================================
# 5. TRAIN / VALIDATION / TEST
# ============================================================

elif section == "✂️ Train / Validation / Test":

    section_header(
        "✂️ Train / Validation / Test",
        "Chronological splitting is used because this "
        "is a time-dependent forecasting problem.",
    )

    split_summary = pd.DataFrame(
        {
            "Dataset": [
                "Training",
                "Validation",
                "Test",
            ],

            "Rows": [
                len(train_data),
                len(validation_data),
                len(test_data),
            ],

            "Percentage": [
                "70%",
                "15%",
                "15%",
            ],
        }
    )

    st.dataframe(
        split_summary,
        use_container_width=True,
        hide_index=True,
    )

    st.markdown(
        "### 🗓️ Split Timeline"
    )

    split_data = pd.DataFrame(
        {
            "Dataset": [
                "Train",
                "Validation",
                "Test",
            ],

            "Start": [
                train_data["timestamp"].min(),
                validation_data["timestamp"].min(),
                test_data["timestamp"].min(),
            ],

            "End": [
                train_data["timestamp"].max(),
                validation_data["timestamp"].max(),
                test_data["timestamp"].max(),
            ],
        }
    )

    st.dataframe(
        split_data,
        use_container_width=True,
        hide_index=True,
    )

    st.markdown(
        "### 📌 Split Strategy"
    )

    st.info(
        "The split is chronological and uses global "
        "target-hour boundaries. All stations belonging "
        "to the same hour remain in the same split. "
        "No random shuffling is performed."
    )

    st.markdown(
        "### Dataset Sizes"
    )

    fig = px.bar(
        split_summary,
        x="Dataset",
        y="Rows",
        text="Rows",
        title="Train / Validation / Test Size",
    )

    fig.update_traces(
        textposition="outside"
    )

    st.plotly_chart(
        fig,
        use_container_width=True,
    )


# ============================================================
# 6. MODEL TRAINING
# ============================================================

elif section == "🤖 Model Training":

    section_header(
        "🤖 Model Training",
        "Multiple regression models and simple "
        "forecasting baselines are evaluated.",
    )

    st.markdown(
        "### Models Evaluated"
    )

    model_table = pd.DataFrame(
        {
            "Model": [
                "Previous Hour",
                "Previous Day",
                "Linear Regression",
                "Random Forest",
                "Gradient Boosting",
                "HistGradientBoosting",
            ],

            "Type": [
                "Baseline",
                "Baseline",
                "Linear Regression",
                "Ensemble",
                "Ensemble",
                "Gradient Boosting",
            ],
        }
    )

    st.dataframe(
        model_table,
        use_container_width=True,
        hide_index=True,
    )

    st.markdown(
        "### Validation Results"
    )

    st.dataframe(
        validation_results,
        use_container_width=True,
        hide_index=True,
    )

    st.markdown(
        "### Model Selection"
    )

    st.info(
        "Candidate models are compared using validation MAE. "
        "The held-out test set is evaluated only after model selection."
    )

    st.success(
        f"Selected model: **{SELECTED_MODEL_NAME}**"
    )


# ============================================================
# 7. MODEL PERFORMANCE
# ============================================================

elif section == "📈 Model Performance":

    section_header(
        "📈 Model Performance",
        "Final held-out test evaluation and prediction diagnostics.",
    )

    st.markdown(
        "### 📊 Final Test Metrics"
    )

    if len(final_row) > 0:

        row = final_row.iloc[0]

        metric_row(
            [
                (
                    "MAE",
                    f"{row['MAE']:.2f}",
                    None,
                ),

                (
                    "RMSE",
                    f"{row['RMSE']:.2f}",
                    None,
                ),

                (
                    "R²",
                    f"{row['R2']:.4f}",
                    None,
                ),

                (
                    "MAPE",
                    f"{row['MAPE']:.2f}%",
                    None,
                ),
            ]
        )

    else:

        st.warning(
            "Gradient Boosting results were not found "
            "in test_results.csv."
        )

    st.caption(
        "MAPE is supplementary because zero actual-demand "
        "values exist."
    )

    st.markdown(
        "### 📈 Model Comparison"
    )

    if {
        "model",
        "MAE",
    }.issubset(
        test_results.columns
    ):

        comparison = (
            test_results
            .sort_values(
                "MAE"
            )
        )

        fig = px.bar(
            comparison,

            x="model",

            y="MAE",

            text="MAE",

            title="Test MAE Comparison",
        )

        fig.update_traces(
            texttemplate="%{text:.2f}",
            textposition="outside",
        )

        fig.update_layout(
            xaxis_title="Model",
            yaxis_title="MAE",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

    st.markdown(
        "### 🎯 Actual vs Predicted"
    )

    if {
        "actual",
        "predicted",
    }.issubset(
        test_predictions.columns
    ):

        fig = px.scatter(
            test_predictions,

            x="actual",

            y="predicted",

            opacity=0.45,

            title="Actual vs Predicted Charging Demand",
        )

        minimum = min(
            test_predictions["actual"].min(),
            test_predictions["predicted"].min(),
        )

        maximum = max(
            test_predictions["actual"].max(),
            test_predictions["predicted"].max(),
        )

        fig.add_trace(
            go.Scatter(
                x=[
                    minimum,
                    maximum,
                ],

                y=[
                    minimum,
                    maximum,
                ],

                mode="lines",

                name="Perfect Prediction",
            )
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

    else:

        st.warning(
            "The prediction file does not contain "
            "'actual' and 'predicted' columns."
        )

    st.markdown(
        "### 📉 Prediction Error Distribution"
    )

    if {
        "actual",
        "predicted",
    }.issubset(
        test_predictions.columns
    ):

        errors = (
            test_predictions["predicted"]
            - test_predictions["actual"]
        )

        fig = px.histogram(
            x=errors,
            nbins=50,
            title="Prediction Error Distribution",
        )

        fig.update_xaxes(
            title="Prediction Error"
        )

        fig.update_yaxes(
            title="Frequency"
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )


# ============================================================
# 8. FORECAST
# ============================================================

elif section == "🔮 Forecast":

    section_header(
        "🔮 Next-Hour Forecast",
        "Generate a historical endpoint next-hour "
        "station-level forecast using the trained model.",
    )

    stations = sorted(
        all_model_data["station_id"]
        .dropna()
        .unique()
        .tolist()
    )

    selected_station = st.selectbox(
        "Select Station",
        stations,
        key="forecast_station",
    )

    station_data = all_model_data[
        all_model_data["station_id"]
        == selected_station
    ].copy()

    station_data = station_data.sort_values(
        "timestamp"
    )

    station_data = station_data.dropna(
        subset=FEATURE_COLUMNS
    )

    if len(station_data) == 0:

        st.error(
            "No model-ready observations are available "
            "for this station."
        )

    else:

        latest = station_data.iloc[-1]

        X_latest = pd.DataFrame(
            [
                [
                    latest[column]
                    for column in FEATURE_COLUMNS
                ]
            ],
            columns=FEATURE_COLUMNS,
        )

        prediction = float(
            model.predict(
                X_latest
            )[0]
        )

        prediction = max(
            0.0,
            prediction,
        )

        forecast_time = (
            pd.to_datetime(
                latest["timestamp"]
            )
            + pd.Timedelta(
                hours=1
            )
        )

        if prediction < 20:

            category = "Low"

        elif prediction < 50:

            category = "Moderate"

        elif prediction < 80:

            category = "High"

        else:

            category = "Very High"

        metric_row(
            [
                (
                    "Forecast Demand",
                    f"{prediction:.2f}",
                    "Predicted demand for the next hour.",
                ),

                (
                    "Forecast Category",
                    category,
                    None,
                ),

                (
                    "Latest Historical Hour",
                    str(
                        latest["timestamp"]
                    ),
                    None,
                ),

                (
                    "Forecast Hour",
                    str(
                        forecast_time
                    ),
                    None,
                ),
            ]
        )

        st.markdown(
            "### 🔮 Forecast Result"
        )

        st.success(
            f"**{selected_station}** predicted demand "
            f"for **{forecast_time}**: "
            f"**{prediction:.2f}**"
        )

        st.markdown(
            "### 📈 Recent Historical Demand"
        )

        recent = station_data[
            [
                "timestamp",
                "charging_demand",
            ]
        ].tail(48)

        fig = px.line(
            recent,

            x="timestamp",

            y="charging_demand",

            markers=True,

            title=(
                f"{selected_station} — "
                "Recent Historical Demand"
            ),
        )

        fig.add_hline(
            y=prediction,

            line_dash="dash",

            annotation_text="Next-hour prediction",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.warning(
            "This forecast uses the historical endpoint "
            "of the available dataset. It is not a live "
            "real-time prediction."
        )


# ============================================================
# 9. STATION ANALYSIS
# ============================================================

elif section == "🏢 Station Analysis":

    section_header(
        "🏢 Station Analysis",
        "Compare prediction error and charging behavior "
        "across all 20 stations.",
    )

    if "station_id" in station_errors.columns:

        station_errors_display = (
            station_errors
            .sort_values(
                "MAE",
                ascending=False,
            )
        )

        st.markdown(
            "### 📉 Prediction Error by Station"
        )

        st.dataframe(
            station_errors_display.style.format(
                {
                    "MAE": "{:.3f}",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

        fig = px.bar(
            station_errors_display,

            x="station_id",

            y="MAE",

            title="Station-wise Test MAE",
        )

        fig.update_layout(
            xaxis_title="Station",
            yaxis_title="MAE",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

    st.markdown(
        "### 📊 Station Demand Summary"
    )

    station_summary = (
        all_model_data
        .groupby(
            "station_id"
        )
        .agg(
            average_demand=(
                "charging_demand",
                "mean",
            ),

            maximum_demand=(
                "charging_demand",
                "max",
            ),

            observations=(
                "charging_demand",
                "count",
            ),
        )
        .reset_index()
        .sort_values(
            "average_demand",
            ascending=False,
        )
    )

    st.dataframe(
        station_summary,
        use_container_width=True,
        hide_index=True,
    )


# ============================================================
# 10. FEATURE IMPORTANCE
# ============================================================

elif section == "⭐ Feature Importance":

    section_header(
        "⭐ Feature Importance",
        "Feature importance from the selected Gradient Boosting model.",
    )

    importance = feature_importance.copy()

    if (
        "feature" not in importance.columns
        and "Feature" in importance.columns
    ):

        importance = importance.rename(
            columns={
                "Feature": "feature"
            }
        )

    if (
        "importance" not in importance.columns
        and "Importance" in importance.columns
    ):

        importance = importance.rename(
            columns={
                "Importance": "importance"
            }
        )

    if {
        "feature",
        "importance",
    }.issubset(
        importance.columns
    ):

        importance = (
            importance
            .sort_values(
                "importance",
                ascending=False,
            )
        )

        st.markdown(
            "### 📊 Feature Importance Chart"
        )

        fig = px.bar(
            importance.sort_values(
                "importance"
            ),

            x="importance",

            y="feature",

            orientation="h",

            title="Gradient Boosting Feature Importance",
        )

        fig.update_layout(
            xaxis_title="Importance",
            yaxis_title="Feature",
        )

        st.plotly_chart(
            fig,
            use_container_width=True,
        )

        st.markdown(
            "### 📋 Feature Importance Table"
        )

        st.dataframe(
            importance.style.format(
                {
                    "importance": "{:.6f}",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

    else:

        st.warning(
            "The feature importance report does not "
            "contain the expected columns."
        )


# ============================================================
# 11. METHODOLOGY
# ============================================================

elif section == "📚 Methodology":

    section_header(
        "📚 Methodology",
        "Technical methodology, assumptions, "
        "leakage controls and project limitations.",
    )

    st.markdown(
        "### 1. Problem Definition"
    )

    st.write(
        "The objective is to predict the next hour's "
        "station-level charging demand using historical information."
    )

    st.markdown(
        "### 2. Original Dataset"
    )

    st.write(
        """
        The original dataset contains 8,354 observations
        and 27 columns. The data contains information about
        stations, vehicles, charging behavior, electricity
        price, renewable energy ratio, traffic, weather and
        other operational variables.
        """
    )

    st.markdown(
        "### 3. Hourly Aggregation"
    )

    st.write(
        """
        Event-level observations are transformed into a
        complete station × hour panel. This creates a
        consistent hourly forecasting structure for all
        stations.
        """
    )

    st.markdown(
        "### 4. Zero-Fill Assumption"
    )

    st.warning(
        """
        Empty station-hours are represented as zero demand
        for the variables explicitly selected for zero filling.
        This is a modeling assumption and should be considered
        when interpreting the results.
        """
    )

    st.markdown(
        "### 5. Feature Engineering"
    )

    st.write(
        """
        The final model uses calendar variables, historical
        demand lags, historical station-load lags, queue lags
        and rolling historical demand statistics.
        """
    )

    st.markdown(
        "### 6. Leakage Prevention"
    )

    st.write(
        """
        Contemporaneous demand-related variables are excluded.
        Lagged features use only previous observations, and
        rolling features are calculated from shifted historical
        demand.
        """
    )

    st.markdown(
        "### 7. Chronological Split"
    )

    st.write(
        """
        The dataset is divided chronologically into 70%
        training, 15% validation and 15% test data.
        No random shuffling is performed.
        """
    )

    st.markdown(
        "### 8. Model Selection"
    )

    st.write(
        """
        Candidate models are compared using validation MAE.
        After model selection, the held-out test set is used
        for final evaluation.
        """
    )

    st.markdown(
        "### 9. Final Model"
    )

    st.success(
        f"The selected model is **{SELECTED_MODEL_NAME}**."
    )

    st.markdown(
        "### 10. Final Test Result"
    )

    if len(final_row) > 0:

        row = final_row.iloc[0]

        result_table = pd.DataFrame(
            {
                "Metric": [
                    "MAE",
                    "RMSE",
                    "R²",
                    "MAPE",
                ],

                "Value": [
                    f"{row['MAE']:.4f}",
                    f"{row['RMSE']:.4f}",
                    f"{row['R2']:.4f}",
                    f"{row['MAPE']:.2f}%",
                ],
            }
        )

        st.dataframe(
            result_table,
            use_container_width=True,
            hide_index=True,
        )

    st.markdown(
        "### 11. Limitation"
    )

    st.info(
        """
        The final test R² is modest. Therefore, the model should
        be described as the best-performing model on this dataset
        and test period among the evaluated candidates, rather
        than as a universally optimal forecasting algorithm.
        """
    )