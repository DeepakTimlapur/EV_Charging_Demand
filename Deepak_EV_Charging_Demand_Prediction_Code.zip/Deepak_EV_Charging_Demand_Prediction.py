# EV Charging Demand Prediction
# Next-Hour Electric Vehicle Charging Demand Forecasting

import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

warnings.filterwarnings("ignore")
pd.set_option("display.max_columns", None)
pd.set_option("display.max_rows", 100)
sns.set_theme(style="whitegrid")

# ============================================================
# 1. LOAD DATASET
# ============================================================
DATA_PATH_CANDIDATES = [
    "EV_Charging_Demand_Dataset_Full.csv",
    os.path.join("data", "EV_Charging_Demand_Dataset_Full.csv"),
    os.path.join("..", "data", "EV_Charging_Demand_Dataset_Full.csv"),
]
DATA_PATH = next((p for p in DATA_PATH_CANDIDATES if os.path.exists(p)), None)
if DATA_PATH is None:
    raise FileNotFoundError(
        "Dataset not found. Place 'EV_Charging_Demand_Dataset_Full.csv' "
        "in the notebook directory or in a data folder."
    )

df = pd.read_csv(DATA_PATH)
print("Dataset loaded successfully.")
print("Path:", DATA_PATH)
print("Shape:", df.shape)

# ============================================================
# 2. DATASET OVERVIEW AND QUALITY CHECKS
# ============================================================
print("\nColumns:")
for i, column in enumerate(df.columns, 1):
    print(f"{i}. {column}")

print("\nFirst 5 rows:")
print(df.head())

print("\nData types:")
print(df.dtypes)

print("\nMissing values:")
print(df.isnull().sum())
print("Total missing values:", df.isnull().sum().sum())
print("Duplicate rows:", df.duplicated().sum())
print("Number of stations:", df["station_id"].nunique())
print("Number of vehicles:", df["vehicle_id"].nunique())
print("Timestamp range:", df["timestamp"].min(), "to", df["timestamp"].max())

# ============================================================
# 3. DATETIME PREPROCESSING
# ============================================================
datetime_columns = ["timestamp", "arrival_time", "charging_start_time", "charging_end_time"]
for column in datetime_columns:
    df[column] = pd.to_datetime(df[column], errors="coerce")

print("\nInvalid datetime values:")
for column in datetime_columns:
    print(column, df[column].isna().sum())

df = df.sort_values(["timestamp", "station_id"]).reset_index(drop=True)

# ============================================================
# 4. TARGET VARIABLE ANALYSIS
# ============================================================
print("\nCharging demand statistics:")
print(df["charging_demand"].describe())

plt.figure(figsize=(10, 5))
sns.histplot(df["charging_demand"], bins=40, kde=True)
plt.title("Distribution of Charging Demand")
plt.xlabel("Charging Demand")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# ============================================================
# 5. STATION-WISE ANALYSIS
# ============================================================
station_summary = (
    df.groupby("station_id")
    .agg(
        records=("station_id", "size"),
        unique_vehicles=("vehicle_id", "nunique"),
        avg_demand=("charging_demand", "mean"),
        max_demand=("charging_demand", "max"),
        avg_power=("charging_power_kW", "mean"),
        total_energy=("energy_consumed_kWh", "sum"),
    )
    .sort_values("avg_demand", ascending=False)
)
print("\nStation-wise summary:")
print(station_summary)

plt.figure(figsize=(12, 6))
station_summary["avg_demand"].sort_values().plot(kind="barh")
plt.title("Average Charging Demand by Station")
plt.xlabel("Average Charging Demand")
plt.ylabel("Station")
plt.tight_layout()
plt.show()

# ============================================================
# 6. LOCATION-WISE ANALYSIS
# ============================================================
location_summary = (
    df.groupby("location_type")
    .agg(
        records=("location_type", "size"),
        stations=("station_id", "nunique"),
        unique_vehicles=("vehicle_id", "nunique"),
        avg_demand=("charging_demand", "mean"),
        max_demand=("charging_demand", "max"),
        avg_power=("charging_power_kW", "mean"),
        total_energy=("energy_consumed_kWh", "sum"),
    )
)
print("\nLocation-wise summary:")
print(location_summary)

plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x="location_type", y="charging_demand")
plt.title("Charging Demand by Location Type")
plt.xlabel("Location Type")
plt.ylabel("Charging Demand")
plt.tight_layout()
plt.show()

# ============================================================
# 7. VEHICLE-TYPE ANALYSIS
# ============================================================
vehicle_summary = (
    df.groupby("vehicle_type")
    .agg(
        observations=("vehicle_type", "size"),
        unique_vehicles=("vehicle_id", "nunique"),
        stations=("station_id", "nunique"),
        avg_demand=("charging_demand", "mean"),
        max_demand=("charging_demand", "max"),
        avg_battery_capacity=("battery_capacity_kWh", "mean"),
        avg_charging_power=("charging_power_kW", "mean"),
        total_energy=("energy_consumed_kWh", "sum"),
    )
)
print("\nVehicle-type summary:")
print(vehicle_summary)

plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x="vehicle_type", y="charging_demand")
plt.title("Charging Demand by Vehicle Type")
plt.xlabel("Vehicle Type")
plt.ylabel("Charging Demand")
plt.tight_layout()
plt.show()

# ============================================================
# 8. TIME-BASED ANALYSIS
# ============================================================
df["hour"] = df["timestamp"].dt.hour
df["date"] = df["timestamp"].dt.date

hourly_demand = df.groupby("hour")["charging_demand"].mean()
plt.figure(figsize=(12, 5))
hourly_demand.plot(marker="o")
plt.title("Average Charging Demand by Hour")
plt.xlabel("Hour of Day")
plt.ylabel("Average Charging Demand")
plt.xticks(range(24))
plt.tight_layout()
plt.show()

day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
day_demand = df.groupby("day_of_week")["charging_demand"].mean().reindex(day_order)
plt.figure(figsize=(10, 5))
day_demand.plot(kind="bar")
plt.title("Average Charging Demand by Day of Week")
plt.xlabel("Day")
plt.ylabel("Average Charging Demand")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

print("\nAverage demand by time slot:")
print(df.groupby("time_slot")["charging_demand"].mean())

# ============================================================
# 9. CORRELATION AND LEAKAGE WARNING
# ============================================================
numeric_columns = df.select_dtypes(include=np.number).columns
correlation_matrix = df[numeric_columns].corr()

plt.figure(figsize=(14, 10))
sns.heatmap(correlation_matrix, cmap="coolwarm", center=0)
plt.title("Correlation Matrix")
plt.tight_layout()
plt.show()

print(
    "\nContemporaneous charging_demand vs station_load correlation:",
    df["charging_demand"].corr(df["station_load"]),
)
print(
    "Leakage control: contemporaneous demand-related variables are not used "
    "as predictive features; only historical lagged information is used."
)

# ============================================================
# 10. HOURLY STATION-LEVEL AGGREGATION
# ============================================================
model_df = df.copy()
model_df["hour_timestamp"] = model_df["timestamp"].dt.floor("h")

station_hour = (
    model_df.groupby(["station_id", "hour_timestamp"])
    .agg(
        charging_demand=("charging_demand", "mean"),
        station_load=("station_load", "mean"),
        queue_length=("queue_length", "mean"),
        energy_consumed_kWh=("energy_consumed_kWh", "sum"),
        waiting_time=("waiting_time", "mean"),
        electricity_price=("electricity_price", "mean"),
        renewable_energy_ratio=("renewable_energy_ratio", "mean"),
    )
    .reset_index()
)
print("\nStation-hour dataset shape:", station_hour.shape)

# ============================================================
# 11. COMPLETE STATION-HOUR GRID
# ============================================================
stations = sorted(station_hour["station_id"].unique())
min_hour = station_hour["hour_timestamp"].min()
max_hour = station_hour["hour_timestamp"].max()
all_hours = pd.date_range(min_hour, max_hour, freq="h")

complete_index = pd.MultiIndex.from_product(
    [stations, all_hours],
    names=["station_id", "hour_timestamp"],
)

station_hour = (
    station_hour.set_index(["station_id", "hour_timestamp"])
    .reindex(complete_index)
    .reset_index()
)

print("Completed station-hour panel:", station_hour.shape)
print("Stations:", station_hour["station_id"].nunique())
print("Hours:", station_hour["hour_timestamp"].nunique())

# Explicit modeling assumption for empty station-hours.
zero_fill_columns = [
    "charging_demand",
    "station_load",
    "queue_length",
    "energy_consumed_kWh",
    "waiting_time",
]
for column in zero_fill_columns:
    station_hour[column] = station_hour[column].fillna(0)

# ============================================================
# 12. CALENDAR FEATURES
# ============================================================
station_hour["hour_of_day"] = station_hour["hour_timestamp"].dt.hour
station_hour["day_of_week"] = station_hour["hour_timestamp"].dt.dayofweek
station_hour["day_of_month"] = station_hour["hour_timestamp"].dt.day
station_hour["month"] = station_hour["hour_timestamp"].dt.month
station_hour["is_weekend"] = (station_hour["day_of_week"] >= 5).astype(int)

station_hour = station_hour.sort_values(
    ["station_id", "hour_timestamp"]
).reset_index(drop=True)

# ============================================================
# 13. HISTORICAL LAG FEATURES
# ============================================================
grouped_demand = station_hour.groupby("station_id")["charging_demand"]
grouped_load = station_hour.groupby("station_id")["station_load"]
grouped_queue = station_hour.groupby("station_id")["queue_length"]

station_hour["demand_lag_1h"] = grouped_demand.shift(1)
station_hour["demand_lag_2h"] = grouped_demand.shift(2)
station_hour["demand_lag_3h"] = grouped_demand.shift(3)
station_hour["demand_lag_24h"] = grouped_demand.shift(24)
station_hour["station_load_lag_1h"] = grouped_load.shift(1)
station_hour["station_load_lag_24h"] = grouped_load.shift(24)
station_hour["queue_lag_1h"] = grouped_queue.shift(1)
station_hour["queue_lag_24h"] = grouped_queue.shift(24)

# ============================================================
# 14. LEAKAGE-SAFE ROLLING FEATURES
# ============================================================
# Shift first, then calculate rolling means, so current demand is excluded.
station_hour["demand_rolling_mean_3h"] = (
    station_hour.groupby("station_id")["charging_demand"]
    .transform(lambda x: x.shift(1).rolling(3, min_periods=3).mean())
)
station_hour["demand_rolling_mean_6h"] = (
    station_hour.groupby("station_id")["charging_demand"]
    .transform(lambda x: x.shift(1).rolling(6, min_periods=6).mean())
)
station_hour["demand_rolling_mean_24h"] = (
    station_hour.groupby("station_id")["charging_demand"]
    .transform(lambda x: x.shift(1).rolling(24, min_periods=24).mean())
)

# ============================================================
# 15. TARGET: NEXT-HOUR DEMAND
# ============================================================
station_hour["next_hour_demand"] = (
    station_hour.groupby("station_id")["charging_demand"].shift(-1)
)

print("\nTotal station-hour rows:", len(station_hour))
print("Missing target values:", station_hour["next_hour_demand"].isna().sum())
print("\nTarget statistics:")
print(station_hour["next_hour_demand"].describe())

# ============================================================
# 16. MODEL FEATURES
# ============================================================
FEATURE_COLUMNS = [
    "hour_of_day",
    "day_of_week",
    "day_of_month",
    "month",
    "is_weekend",
    "demand_lag_1h",
    "demand_lag_2h",
    "demand_lag_3h",
    "demand_lag_24h",
    "station_load_lag_1h",
    "station_load_lag_24h",
    "queue_lag_1h",
    "queue_lag_24h",
    "demand_rolling_mean_3h",
    "demand_rolling_mean_6h",
    "demand_rolling_mean_24h",
]
TARGET_COLUMN = "next_hour_demand"

# Contemporaneous leakage-prone fields are intentionally absent.
FORBIDDEN_CONTEMPORANEOUS = [
    "charging_demand",
    "station_load",
    "queue_length",
    "energy_consumed_kWh",
    "waiting_time",
]

print("\nNumber of features:", len(FEATURE_COLUMNS))
print("Excluded contemporaneous fields:", FORBIDDEN_CONTEMPORANEOUS)

# ============================================================
# 17. MODEL-READY DATA
# ============================================================
model_data = station_hour.dropna(
    subset=FEATURE_COLUMNS + [TARGET_COLUMN]
).copy()
model_data = model_data.sort_values("hour_timestamp").reset_index(drop=True)

print("Model-ready rows:", len(model_data))
print(
    "Missing feature/target values:",
    model_data[FEATURE_COLUMNS + [TARGET_COLUMN]].isna().sum().sum(),
)

# ============================================================
# 18. CHRONOLOGICAL 70/15/15 SPLIT
# ============================================================
unique_hours = np.sort(model_data["hour_timestamp"].unique())
n_hours = len(unique_hours)
train_end = int(n_hours * 0.70)
validation_end = int(n_hours * 0.85)

train_hours = unique_hours[:train_end]
validation_hours = unique_hours[train_end:validation_end]
test_hours = unique_hours[validation_end:]

train_data = model_data[model_data["hour_timestamp"].isin(train_hours)].copy()
validation_data = model_data[model_data["hour_timestamp"].isin(validation_hours)].copy()
test_data = model_data[model_data["hour_timestamp"].isin(test_hours)].copy()

print("\nTrain:", train_data.shape)
print("Validation:", validation_data.shape)
print("Test:", test_data.shape)
print("Train period:", train_data["hour_timestamp"].min(), "to", train_data["hour_timestamp"].max())
print("Validation period:", validation_data["hour_timestamp"].min(), "to", validation_data["hour_timestamp"].max())
print("Test period:", test_data["hour_timestamp"].min(), "to", test_data["hour_timestamp"].max())

train_hour_set = set(train_data["hour_timestamp"])
validation_hour_set = set(validation_data["hour_timestamp"])
test_hour_set = set(test_data["hour_timestamp"])
print("Train/Validation overlap:", len(train_hour_set & validation_hour_set))
print("Train/Test overlap:", len(train_hour_set & test_hour_set))
print("Validation/Test overlap:", len(validation_hour_set & test_hour_set))

# ============================================================
# 19. X / y MATRICES
# ============================================================
X_train = train_data[FEATURE_COLUMNS]
y_train = train_data[TARGET_COLUMN]
X_validation = validation_data[FEATURE_COLUMNS]
y_validation = validation_data[TARGET_COLUMN]
X_test = test_data[FEATURE_COLUMNS]
y_test = test_data[TARGET_COLUMN]

print("X_train:", X_train.shape)
print("X_validation:", X_validation.shape)
print("X_test:", X_test.shape)

# ============================================================
# 20. METRICS
# ============================================================
def calculate_mape(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    mask = y_true != 0
    if mask.sum() == 0:
        return np.nan
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100


def evaluate_model(y_true, y_pred):
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": np.sqrt(mean_squared_error(y_true, y_pred)),
        "R2": r2_score(y_true, y_pred),
        "MAPE": calculate_mape(y_true, y_pred),
    }

# ============================================================
# 21. BASELINE MODELS
# ============================================================
baseline_results = []

for name, column in [
    ("Previous Hour", "demand_lag_1h"),
    ("Previous Day", "demand_lag_24h"),
]:
    metrics = evaluate_model(y_validation, validation_data[column])
    metrics["model"] = name
    baseline_results.append(metrics)

baseline_results_df = pd.DataFrame(baseline_results)[
    ["model", "MAE", "RMSE", "R2", "MAPE"]
].sort_values("MAE")
print("\nValidation baseline results:")
print(baseline_results_df)

# ============================================================
# 22. MACHINE LEARNING MODELS
# ============================================================
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(
        n_estimators=200, random_state=42, n_jobs=-1
    ),
    "Gradient Boosting": GradientBoostingRegressor(
        n_estimators=200, learning_rate=0.05, max_depth=3, random_state=42
    ),
    "HistGradientBoosting": HistGradientBoostingRegressor(
        max_iter=200, learning_rate=0.05, max_leaf_nodes=31, random_state=42
    ),
}

validation_results = []
trained_models = {}

for name, model in models.items():
    model.fit(X_train, y_train)
    prediction = model.predict(X_validation)
    metrics = evaluate_model(y_validation, prediction)
    metrics["model"] = name
    validation_results.append(metrics)
    trained_models[name] = model

validation_results_df = pd.DataFrame(validation_results)[
    ["model", "MAE", "RMSE", "R2", "MAPE"]
].sort_values("MAE")

print("\nValidation ML results:")
print(validation_results_df)

# ============================================================
# 23. MODEL SELECTION
# ============================================================
all_validation_results = pd.concat(
    [baseline_results_df, validation_results_df], ignore_index=True
).sort_values("MAE").reset_index(drop=True)

print("\nAll validation results:")
print(all_validation_results)

selected_model_name = validation_results_df.iloc[0]["model"]
selected_model = trained_models[selected_model_name]
print("\nSelected model:", selected_model_name)
print("Selection criterion: lowest validation MAE")

# ============================================================
# 24. FINAL TEST EVALUATION
# ============================================================
test_predictions = selected_model.predict(X_test)
test_metrics = evaluate_model(y_test, test_predictions)

print("\nFinal test metrics:")
for metric, value in test_metrics.items():
    print(f"{metric}: {value:.6f}")

# Compare all models on the held-out test period for reporting.
test_model_results = []
for name, column in [
    ("Previous Hour", "demand_lag_1h"),
    ("Previous Day", "demand_lag_24h"),
]:
    metrics = evaluate_model(y_test, test_data[column])
    metrics["model"] = name
    test_model_results.append(metrics)

for name, model in trained_models.items():
    prediction = model.predict(X_test)
    metrics = evaluate_model(y_test, prediction)
    metrics["model"] = name
    test_model_results.append(metrics)

test_results_df = pd.DataFrame(test_model_results)[
    ["model", "MAE", "RMSE", "R2", "MAPE"]
].sort_values("MAE")

print("\nHeld-out test comparison:")
print(test_results_df)

# ============================================================
# 25. ACTUAL VS PREDICTED
# ============================================================
prediction_results = test_data[
    ["station_id", "hour_timestamp", "next_hour_demand"]
].copy()
prediction_results["predicted_demand"] = test_predictions

print("\nPrediction sample:")
print(prediction_results.head(20))

plt.figure(figsize=(12, 6))
plt.plot(prediction_results["next_hour_demand"].values[:300], label="Actual")
plt.plot(prediction_results["predicted_demand"].values[:300], label="Predicted")
plt.title("Actual vs Predicted Next-Hour Charging Demand")
plt.xlabel("Test Observations")
plt.ylabel("Charging Demand")
plt.legend()
plt.tight_layout()
plt.show()

# ============================================================
# 26. PREDICTION ERROR ANALYSIS
# ============================================================
prediction_results["error"] = (
    prediction_results["next_hour_demand"] - prediction_results["predicted_demand"]
)

plt.figure(figsize=(10, 5))
sns.histplot(prediction_results["error"], bins=40, kde=True)
plt.title("Prediction Error Distribution")
plt.xlabel("Prediction Error")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

plt.figure(figsize=(8, 8))
sns.scatterplot(
    data=prediction_results,
    x="next_hour_demand",
    y="predicted_demand",
    alpha=0.5,
)
min_value = min(
    prediction_results["next_hour_demand"].min(),
    prediction_results["predicted_demand"].min(),
)
max_value = max(
    prediction_results["next_hour_demand"].max(),
    prediction_results["predicted_demand"].max(),
)
plt.plot([min_value, max_value], [min_value, max_value], linestyle="--")
plt.title("Actual vs Predicted Demand")
plt.xlabel("Actual Demand")
plt.ylabel("Predicted Demand")
plt.tight_layout()
plt.show()

# ============================================================
# 27. FEATURE IMPORTANCE
# ============================================================
if hasattr(selected_model, "feature_importances_"):
    feature_importance = pd.DataFrame({
        "feature": FEATURE_COLUMNS,
        "importance": selected_model.feature_importances_,
    }).sort_values("importance", ascending=False)

    print("\nFeature importance:")
    print(feature_importance)

    plt.figure(figsize=(10, 7))
    sns.barplot(data=feature_importance, x="importance", y="feature")
    plt.title("Feature Importance of Selected Model")
    plt.xlabel("Importance")
    plt.ylabel("Feature")
    plt.tight_layout()
    plt.show()

# ============================================================
# 28. STATION-WISE ERROR ANALYSIS
# ============================================================
station_error_rows = []
for station_id, group in prediction_results.groupby("station_id"):
    station_error_rows.append({
        "station_id": station_id,
        "MAE": mean_absolute_error(
            group["next_hour_demand"], group["predicted_demand"]
        ),
        "RMSE": np.sqrt(mean_squared_error(
            group["next_hour_demand"], group["predicted_demand"]
        )),
        "observations": len(group),
    })

station_errors = pd.DataFrame(station_error_rows).sort_values(
    "MAE", ascending=False
)
print("\nStation-wise error analysis:")
print(station_errors)

plt.figure(figsize=(12, 7))
sns.barplot(data=station_errors, x="MAE", y="station_id")
plt.title("Station-Wise Prediction Error")
plt.xlabel("MAE")
plt.ylabel("Station")
plt.tight_layout()
plt.show()

# ============================================================
# 29. NEXT-HOUR FORECAST
# ============================================================
latest_rows = (
    model_data
    .sort_values(["station_id", "hour_timestamp"])
    .groupby("station_id")
    .tail(1)
    .copy()
)

latest_rows["forecast"] = selected_model.predict(
    latest_rows[FEATURE_COLUMNS]
)
latest_rows["forecast_hour"] = latest_rows["hour_timestamp"] + pd.Timedelta(hours=1)

forecast_output = latest_rows[
    ["station_id", "hour_timestamp", "forecast_hour", "forecast"]
].copy()
forecast_output = forecast_output.rename(
    columns={
        "hour_timestamp": "latest_observation",
        "forecast": "predicted_next_hour_demand",
    }
)

def demand_category(value):
    if value < 20:
        return "Low"
    if value < 50:
        return "Medium"
    return "High"

forecast_output["demand_category"] = forecast_output[
    "predicted_next_hour_demand"
].apply(demand_category)

print("\nNext-hour forecast:")
print(forecast_output)

# ============================================================
# 30. FINAL SUMMARY
# ============================================================
print("\n" + "=" * 60)
print("FINAL MODEL SUMMARY")
print("=" * 60)
print("Selected Model:", selected_model_name)
print(f"MAE  : {test_metrics['MAE']:.6f}")
print(f"RMSE : {test_metrics['RMSE']:.6f}")
print(f"R2   : {test_metrics['R2']:.6f}")
print(f"MAPE : {test_metrics['MAPE']:.6f}%")
print("\nNote: MAPE is supplementary and is calculated only where actual demand is non-zero.")
