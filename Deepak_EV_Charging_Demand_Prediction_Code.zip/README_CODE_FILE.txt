EV Charging Demand Prediction - Code Submission

Main code file:
Deepak_EV_Charging_Demand_Prediction.ipynb

Python source version:
Deepak_EV_Charging_Demand_Prediction.py

Required dataset:
EV_Charging_Demand_Dataset_Full.csv

The notebook/source includes:
- Data loading and validation
- EDA
- Station-wise, location-wise and vehicle-type analysis
- Time-based analysis
- Station-hour aggregation and complete station-hour grid
- Explicit zero-fill assumption for empty station-hours
- Calendar, lag and leakage-safe rolling features
- next_hour_demand target
- Leakage prevention
- Chronological 70/15/15 split
- Previous-hour and previous-day baselines
- Linear Regression
- Random Forest
- Gradient Boosting
- HistGradientBoosting
- Validation-based model selection
- Final held-out test evaluation
- Actual vs predicted plots
- Error analysis
- Feature importance
- Station-wise error analysis
- Next-hour forecasting

Place the dataset in the same directory as the notebook/script, or in:
data/EV_Charging_Demand_Dataset_Full.csv
